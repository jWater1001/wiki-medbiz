package com.medbiz.core.databinding.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "body_temperature")
data class BodyTemperatureEntity(
        @ColumnInfo(name = "bodyTemperature") var bodyTemperature: Double,
        @ColumnInfo(name = "context") var context: String?,
        @ColumnInfo(name = "timeStamp") var timeStamp: Long,
        @ColumnInfo(name = "memo") var memo: String?
) {
    @PrimaryKey(autoGenerate = true) var id: Int? = null

}
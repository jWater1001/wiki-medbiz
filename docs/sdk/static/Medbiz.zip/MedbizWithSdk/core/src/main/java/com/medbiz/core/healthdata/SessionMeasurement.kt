package com.medbiz.core.healthdata
class SessionMeasurement(
        startTime: Long,
        endTime: Long,
        timeOffset: Long) {
    var startTime = startTime
    var endTime = endTime
    var timeOffset = timeOffset
}

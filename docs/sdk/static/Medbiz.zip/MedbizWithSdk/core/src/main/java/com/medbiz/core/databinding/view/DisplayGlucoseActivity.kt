package com.medbiz.core.databinding.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityDisplayGlucoseBinding
import com.medbiz.core.databinding.adapter.GlucosePagerAdapter
import com.medbiz.core.databinding.viewModel.DisplayGlucoseViewModel

class DisplayGlucoseActivity : AppCompatActivity() {
    private lateinit var viewModel: DisplayGlucoseViewModel
    lateinit var binding: ActivityDisplayGlucoseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_display_glucose)
        viewModel = ViewModelProvider(this).get(DisplayGlucoseViewModel::class.java)
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.back)
        }
        binding.viewPager.adapter = GlucosePagerAdapter(supportFragmentManager, FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
        binding.tabLayout.setupWithViewPager(binding.viewPager)
    }
}

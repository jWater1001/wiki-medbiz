package com.medbiz.core.databinding.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.viewModel.LoginIntroViewModel
import com.medbiz.core.databinding.ActivityLoginIntroBinding

class LoginIntroActivity : AppCompatActivity() {
    var tag = LoginIntroActivity::class.java.name
    private lateinit var binding: ActivityLoginIntroBinding
    lateinit var loginIntroViewModel: LoginIntroViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_intro)

        loginIntroViewModel = ViewModelProvider(this).get(LoginIntroViewModel::class.java)
        binding.bgImage = R.drawable.login_background_04
        binding.loginIntroViewModel = loginIntroViewModel

//        binding.test = this.resources.getDrawable(R.drawable.login_animation_frame, null)
//        val imgView = binding.imageViewAnimationFrame
//        val background = imgView.drawable!! as AnimationDrawable
//        background.setEnterFadeDuration(700)
//        background.setExitFadeDuration(600)
//        background.start()


    }
}

package com.medbiz.core.databinding.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.medbiz.core.R
import com.medbiz.core.databinding.FragmentDisplayBodyTemperatureStaticsBinding


class DisplayBodyTemperatureStaticsFragment : Fragment() {
    lateinit var binding: FragmentDisplayBodyTemperatureStaticsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_display_body_temperature_statics, container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }
}

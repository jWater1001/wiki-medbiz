package com.medbiz.core.healthdata

import kotlin.properties.Delegates

open class HealthConstants {
    var dataType by Delegates.notNull<Int>()

    companion object {
        const val STEP_COUNT = 0
        const val BLOOD_PRESSURE = 1
        const val GLUCOSE = 2
        const val BODY_TEMPERATURE = 3
        const val WATER_INTAKE = 4
        const val WEIGHT = 5
    }

}




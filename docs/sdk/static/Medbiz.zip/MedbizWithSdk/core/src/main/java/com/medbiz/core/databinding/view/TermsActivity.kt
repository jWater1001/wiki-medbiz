package com.medbiz.core.databinding.view

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.statusBarHeight
import com.medbiz.core.databinding.viewModel.TermsViewModel
import com.medbiz.core.databinding.ActivityTermsBinding
import com.medbiz.core.singleton.Preferences


class TermsActivity : AppCompatActivity() {
    var tag = TermsActivity::class.java.name
    private lateinit var binding: ActivityTermsBinding
    lateinit var termsViewModel: TermsViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_terms)

        // status bar transparent & padding
        binding.textView.setPadding(0, statusBarHeight(this), 0, 0)

        termsViewModel = ViewModelProvider(this).get(TermsViewModel::class.java)
        val animFadeInSlideUp = AnimationUtils.loadAnimation(this, R.anim.fade_in_slide_up)!!

        binding.terms.visibility = View.VISIBLE
        binding.terms.startAnimation(animFadeInSlideUp)

        termsViewModel.isAgree.observe(this,  Observer<Boolean> { checkBoxFlag ->
            binding.termsBar.nextButton.isEnabled = checkBoxFlag
            if(checkBoxFlag)
                binding.termsBar.nextButton.setTextColor(ContextCompat.getColor(this, R.color.colorBlack))
            else
                binding.termsBar.nextButton.setTextColor(ContextCompat.getColor(this, R.color.colorDADADA))
        })

        termsViewModel.buttonLiveData.observe(this,  Observer<Boolean> { isTouched ->
            if(isTouched){
                val intent = Intent(this@TermsActivity, LoginIntroActivity::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                finish()
            }
        })

        binding.bgImage = R.drawable.login_background_01
        binding.termsViewModel = termsViewModel

        binding.termsContent.locationAgreementCheckBox.setOnClickListener {
            val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
            if (bluetoothAdapter == null) {
                // Device doesn't support Bluetooth
                Toast.makeText(this, "Bluetooth 기능을 지원하지 않습니다.", Toast.LENGTH_SHORT).show()
            } else {
                if (!bluetoothAdapter.isEnabled) {
                    val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                    ActivityCompat.startActivityForResult(this, enableBtIntent, TermsViewModel.REQUEST_ENABLE_BT, null)
                } else {
                    checkLocationPermission()
                }
            }
            termsViewModel.locationAgreementCheckBox = binding.termsContent.locationAgreementCheckBox.isChecked
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode) {
            TermsViewModel.REQUEST_ENABLE_BT -> {
                if (resultCode == RESULT_OK) {
                    Toast.makeText(this, "Bluetooth Activation", Toast.LENGTH_SHORT).show()
                    checkLocationPermission()
                }
                else if (resultCode == RESULT_CANCELED)
                    Toast.makeText(this, "Bluetooth is not working", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            TermsViewModel.PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION -> {
                // If request is cancelled, the result arrays are empty.
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return
            }

            // Add other 'when' lines to check for other
            // permissions this app might request.
            else -> {
                // Ignore all other requests.
            }
        }
    }

    fun checkLocationPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                        TermsViewModel.PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION)
            }
        } else {
            // Permission has already been granted
        }
    }
}

package com.medbiz.core.databinding.view

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.medbiz.core.R
import com.medbiz.core.singleton.Preferences
import com.medbiz.core.databinding.ActivitySplashBinding
import kotlinx.coroutines.*

class SplashActivity : AppCompatActivity() {
    var tag = SplashActivity::class.java.name
    private lateinit var binding: ActivitySplashBinding
    private val splashJob = SupervisorJob()
    private val splashScope = CoroutineScope(Dispatchers.Main + splashJob)

    companion object {
        private const val SPLASH_TIME_OUT:Long = 1000
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)

        splashScope.launch {
            delay(SPLASH_TIME_OUT)
            Log.d(tag, "agreementTerms: ${Preferences.agreementTerms}")
            if(!Preferences.agreementTerms) {
                var intent = Intent(this@SplashActivity, TermsActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                var intent = Intent(this@SplashActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}

package com.medbiz.core.databinding.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityDisplayBodyTemperatureBinding
import com.medbiz.core.databinding.adapter.BloodPressurePagerAdapter
import com.medbiz.core.databinding.adapter.BodyTemperaturePagerAdapter
import com.medbiz.core.databinding.viewModel.DisplayBodyTemperatureViewModel

class DisplayBodyTemperatureActivity : AppCompatActivity() {
    private lateinit var viewModel: DisplayBodyTemperatureViewModel
    lateinit var binding: ActivityDisplayBodyTemperatureBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_display_body_temperature)
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.back)
        }
        binding.viewPager.adapter = BodyTemperaturePagerAdapter(supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
        binding.tabLayout.setupWithViewPager(binding.viewPager)
    }
}
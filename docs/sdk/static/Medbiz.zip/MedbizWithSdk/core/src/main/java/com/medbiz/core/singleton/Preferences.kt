package com.medbiz.core.singleton

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import java.util.*

object Preferences {
    private const val SAVED_ID = "SAVED_ID"
    private const val SAVED_PWD = "SAVED_PWD"
    private const val AGREEMENT_TERMS = "AGREEMENT_TERMS"
    private const val AGREEMENT_LOCATION_ACCESS = "AGREEMENT_LOCATION_ACCESS"
    private const val USER_GENDER = "USER_GENDER"
    private const val USER_BIRTHDAY = "USER_BIRTHDAY"
    private const val USER_HEIGHT = "USER_HEIGHT"
    private const val USER_WEIGHT = "USER_WEIGHT"
    private const val USER_INFO_COMPLETE_FLAG = "USER_INFO_COMPLETE_FLAG"

    private lateinit var preferences: SharedPreferences

    fun init(context: Context) {
        preferences = context.getSharedPreferences(context.packageName, Activity.MODE_PRIVATE)
    }

    var agreementTerms: Boolean
        get() = preferences.getBoolean(AGREEMENT_TERMS, false)
        set(value) = preferences.edit {
            putBoolean(AGREEMENT_TERMS, value)
        }

    var agreementLocationAccess: Boolean
        get() = preferences.getBoolean(AGREEMENT_LOCATION_ACCESS, false)
        set(value) = preferences.edit {
            putBoolean(AGREEMENT_TERMS, value)
        }

    var savedId: String?
        get() = preferences.getString(SAVED_ID, null)
        set(value) = preferences.edit {
            putString(SAVED_ID, value)
        }

    var savedPwd: String?
        get() = preferences.getString(SAVED_PWD, null)
        set(value) = preferences.edit {
            putString(SAVED_PWD, value)
        }

    var gender: String?
        get() = preferences.getString(USER_GENDER, null)
        set(value) = preferences.edit {
            putString(USER_GENDER, value)
        }

    var birthday: String?
        get() = preferences.getString(USER_BIRTHDAY, null)
        set(value) = preferences.edit {
            putString(USER_BIRTHDAY, value)
        }

    var height: String?
        get() = preferences.getString(USER_HEIGHT, null)
        set(value) = preferences.edit {
            putString(USER_HEIGHT, value)
        }

    var weight: String?
        get() = preferences.getString(USER_WEIGHT, null)
        set(value) = preferences.edit {
            putString(USER_WEIGHT, value)
        }

    var userInfoCompleteFlag: Boolean
        get() = preferences.getBoolean(USER_INFO_COMPLETE_FLAG, false)
        set(value) = preferences.edit {
            putBoolean(USER_INFO_COMPLETE_FLAG, value)
        }

}
package com.medbiz.core.databinding.recyclerview.decoration

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView


class ItemDecorationWithSpace(space: Int): RecyclerView.ItemDecoration() {
    var sp = space
    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        super.getItemOffsets(outRect, view, parent, state)
        val itemPosition = parent.getChildAdapterPosition(view)

        // no position, leave it alone
        if (itemPosition == RecyclerView.NO_POSITION) {
            return
        }

        val itemCount = state.itemCount

        outRect.set(sp, sp, sp, sp)
        // first item set(int left, int top, int right, int bottom) {
//        if (itemPosition == 0) {
//            outRect.set(sp, sp*2, sp, 0)
//        } else if (itemCount > 0 && itemPosition == itemCount - 1) {
//            outRect.set(sp, 0, sp, sp*2)
//        } else {
//            outRect.set(sp, sp, sp, sp)
//        }
    }
}

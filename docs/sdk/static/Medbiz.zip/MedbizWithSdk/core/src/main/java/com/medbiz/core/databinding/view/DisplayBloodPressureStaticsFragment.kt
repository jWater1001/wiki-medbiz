package com.medbiz.core.databinding.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.FragmentDisplayBloodPressureStaticsBinding
import com.medbiz.core.databinding.viewModel.DisplayBloodPressureViewModel

class DisplayBloodPressureStaticsFragment : Fragment() {
    lateinit var binding: FragmentDisplayBloodPressureStaticsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_display_blood_pressure_statics, container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }
}

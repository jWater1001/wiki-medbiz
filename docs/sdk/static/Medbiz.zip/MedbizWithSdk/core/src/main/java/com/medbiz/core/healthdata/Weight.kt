package com.medbiz.core.healthdata

class Weight: HealthConstants() {
    val healthDataType = "com.medbiz.core.healthdata.weight"
    var weight = 5

    init {
        super.dataType = WEIGHT
    }

}

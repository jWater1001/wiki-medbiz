package com.medbiz.core.databinding.recyclerview.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.medbiz.core.R
import com.medbiz.core.databinding.recyclerview.item.GlucoseContextMealItem


class GlucoseContextMealAdapter : RecyclerView.Adapter<GlucoseContextMealAdapter.ViewHolder>() {
    val tag =  GlucoseContextMealAdapter::class.java.name
    private var itemList: List<GlucoseContextMealItem> = listOf()

    private var savedContextMealIcon: Int? = null
    private var savedContextMealIconId: ImageView? = null

    var selectedContextMeal: String? = null
    override fun getItemCount(): Int {
        return itemList.size
    }

    fun setItemList(itemList: List<GlucoseContextMealItem>) {
        this.itemList = itemList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_glucose_context_meal, parent, false)
        return ViewHolder(view)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val contextMealIcon = itemView.findViewById<ImageView>(R.id.contextMealIcon)
        private val contextMealDescription = itemView.findViewById<TextView>(R.id.contextMealDescription)


        fun bind(item: GlucoseContextMealItem) {
            contextMealIcon.setImageResource(item.contextMealIcon)
            contextMealDescription.text = item.contextMealDescription

            contextMealIcon.setOnClickListener {
                if(contextMealIcon != savedContextMealIconId) {
                    // selected item is reversal
                    contextMealIcon.setImageResource(item.contextMealReversalIcon)

                    // previous selected item set original image
                    savedContextMealIconId?.setImageResource(savedContextMealIcon!!)

                    // save selected item
                    savedContextMealIcon = item.contextMealIcon
                    savedContextMealIconId = contextMealIcon
                    selectedContextMeal = item.contextMealValue
                }
            }
        }
    }


}
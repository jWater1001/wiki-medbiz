package com.medbiz.core.databinding.view

import android.bluetooth.BluetoothGattDescriptor
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.FragmentDisplayBloodPressureBinding
import com.medbiz.core.databinding.viewModel.DisplayBloodPressureViewModel
import java.text.SimpleDateFormat
import java.util.*


class DisplayBloodPressureFragment : Fragment() {
    private lateinit var viewModel: DisplayBloodPressureViewModel
    lateinit var binding: FragmentDisplayBloodPressureBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_display_blood_pressure, container,false)

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(DisplayBloodPressureViewModel::class.java)
        binding.viewModel = viewModel

        viewModel.bloodPressure.observe(viewLifecycleOwner,  Observer { data ->
            if(data == null) {
                binding.noDataTextView.isVisible = true
                binding.latestMeasuredBloodPressure.isVisible = false
                binding.latestMeasuredTime.isVisible = false
            } else {
                binding.noDataTextView.isVisible = false
                binding.latestMeasuredBloodPressure.isVisible = true
                binding.latestMeasuredTime.isVisible = true

                val bloodPressureValue = SpannableString(data.systolic.toString() +
                        "/" + data.diastolic.toString() +
                        " mmHg")

                bloodPressureValue.setSpan(RelativeSizeSpan(0.3f), bloodPressureValue.length-4, bloodPressureValue.length, 0)
                binding.latestMeasuredBloodPressure.text = bloodPressureValue
                binding.latestMeasuredTime.text = SimpleDateFormat("yyyy년 MM월 dd일(E) HH:mm").format(Date(data.timeStamp))
            }
        })
    }
    override fun onResume() {
        super.onResume()
        viewModel.bindService(activity!!.application)
    }
    override fun onStop() {
        super.onStop()
        viewModel.unbindService(activity!!.application)
    }
}

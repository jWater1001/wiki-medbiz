package com.medbiz.core.databinding.viewModel

import android.app.Application
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.content.*
import android.os.IBinder
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.repository.BloodPressureRepository
import com.medbiz.core.databinding.view.InputBloodPressureActivity
import com.medbiz.core.le.BloodPressureGattAttributes
import com.medbiz.core.le.BloodPressureService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.*

class DisplayBloodPressureViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = DisplayBloodPressureViewModel::class.java.name
    private val repository = BloodPressureRepository(application)
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)

    private var mConnectedDeviceName: String? = null
    private var mService: BloodPressureService? = null
    var mBlpService: BluetoothGattService? = null
    var mBlpChar: BluetoothGattCharacteristic? = null
    var bloodPressure = repository.getLatestMeasuredData()

    init {

    }

    private val mServiceConnection= object : ServiceConnection {
        override fun onServiceConnected(componentName: ComponentName, service: IBinder) {
            mService = (service as BloodPressureService.LocalBinder).service
            Log.i(tag, "BloodPressureService::onServiceConnected() Success !! " + mService.toString())
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            Log.i(tag, "BloodPressureService::onServiceDisconnected() Success !! " + mService.toString())
            mService?.disconnect()
        }
    }
    
    private val mGattUpdateReceiver= object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (BloodPressureGattAttributes.ACTION_GATT_CONNECTED == action) {
                Log.d(tag, "[ACTION_GATT_CONNECTED]")
            } else if (BloodPressureGattAttributes.ACTION_GATT_DISCONNECTED == action) {
                Log.d(tag, "[ACTION_GATT_DISCONNECTED]")
            } else if (BloodPressureGattAttributes.ACTION_GATT_SERVICES_DISCOVERED == action) {
                Log.d(tag, "[ACTION_GATT_SERVICES_DISCOVERED] ")
                mBlpService = mService!!.getGattService(BloodPressureGattAttributes.BLOOD_PRESSURE_SERVICE_UUID)
                Log.d(tag, "mBlpService is : " + mBlpService!!.uuid.toString())
                mBlpChar = mBlpService!!.getCharacteristic(BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CHAR_UUID)
                Log.d(tag, "mBlpChar is : " + mBlpChar!!.uuid.toString())
                Log.d(tag, "BroadcastReceiver: ACTION_GATT_CHARACTERISTIC_UUID : " + mBlpChar!!.uuid.toString())
                val mBlpDescriptor: BluetoothGattDescriptor = mBlpChar!!.getDescriptor(BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CCCD_UUID)
                Log.d(tag, "BroadcastReceiver: ACTION_GATT_CCCD_UUID : " + mBlpDescriptor.uuid.toString())
                mService!!.setCharacteristicIndication(mBlpChar!!, true)
            } else if (BloodPressureGattAttributes.ACTION_DATA_AVAILABLE == action) {
                Log.d(tag, "BroadcastReceiver: ACTION_DATA_AVAILABLE New Data!!! ")
                val systolic = intent.getIntExtra(BloodPressureGattAttributes.EXTRA_SYSTOLIC, 0)
                val diastolic = intent.getIntExtra(BloodPressureGattAttributes.EXTRA_DIASTOLIC, 0)
                val map = intent.getIntExtra(BloodPressureGattAttributes.EXTRA_MAP, 0)
                val pulse = intent.getIntExtra(BloodPressureGattAttributes.EXTRA_PULSE, 0)
                val timeStamp = Date().time

                var measuredData = BloodPressureEntity(
                        systolic = systolic,
                        diastolic = diastolic,
                        pulse = pulse,
                        map = map,
                        timeStamp = timeStamp,
                        pill = null,
                        memo = null
                )

                scope.launch {
                    // call DB insert
                    repository.insert(measuredData)
                    // call Health API
                }


            } else if (BloodPressureGattAttributes.ACTION_FIND_DEVICE == action) {
                val deviceMacAddress = intent.getStringExtra(BloodPressureGattAttributes.EXTRA_DATA_DEVICE_ADDRESS)
                val res: Boolean = mService!!.connect(deviceMacAddress)
                Log.d(tag, "[ACTION_FIND_DEVICE] @" + deviceMacAddress + "res : " + res)
                if (res) {
                    mConnectedDeviceName = intent.getStringExtra(BloodPressureGattAttributes.EXTRA_DATA_DEVICE_NAME)
                    Log.d(tag, "[ACTION_FIND_DEVICE] mConnectedDeviceName : $mConnectedDeviceName")
                } else {
                }
            }
        }
    }

    private fun makeGattUpdateIntentFilter(): IntentFilter {
        val intentFilter = IntentFilter()
        intentFilter.addAction(BloodPressureGattAttributes.ACTION_GATT_CONNECTED)
        intentFilter.addAction(BloodPressureGattAttributes.ACTION_GATT_DISCONNECTED)
        intentFilter.addAction(BloodPressureGattAttributes.ACTION_GATT_SERVICES_DISCOVERED)
        intentFilter.addAction(BloodPressureGattAttributes.ACTION_DATA_AVAILABLE)
        intentFilter.addAction(BloodPressureGattAttributes.ACTION_FIND_DEVICE)
        return intentFilter
    }

    // The code below is BLE control source
    fun bindService(application: Application) {
        var intent = Intent(application, BloodPressureService::class.java)
        application.registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter())
        application.bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE)

    }

    fun unbindService(application: Application) {
        application.unregisterReceiver(mGattUpdateReceiver);
        application.unbindService(mServiceConnection)

    }

    fun inputBloodPressureData(view: View){
        var intent = Intent(view.context, InputBloodPressureActivity::class.java)
        ContextCompat.startActivity(view.context, intent, null)
    }
}

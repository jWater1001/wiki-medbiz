package com.medbiz.core.databinding.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.KeyboardVisibilityUtils
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityLoginBinding
import com.medbiz.core.databinding.viewModel.LoginViewModel


class LoginActivity : AppCompatActivity() {

    lateinit var binding: ActivityLoginBinding
    lateinit var viewModel: LoginViewModel
    private lateinit var keyboardVisibilityUtils: KeyboardVisibilityUtils


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)

        keyboardVisibilityUtils = KeyboardVisibilityUtils(window,
                onShowKeyboard = {
                    keyboardHeight -> binding.scrollLayout.run {
                        smoothScrollTo(scrollX, scrollY + keyboardHeight)
                    }
                }
        )
        viewModel = ViewModelProvider(this).get(LoginViewModel::class.java)
        binding.viewModel = viewModel
        
        viewModel.usernameLiveData.observe(this,  Observer<String> { username ->
            binding.username = username
            binding.inputEditTextUserName.requestFocus()
        })

        viewModel.passwordLiveData.observe(this,  Observer<String> { password ->
            binding.password = password
        })
    }

}

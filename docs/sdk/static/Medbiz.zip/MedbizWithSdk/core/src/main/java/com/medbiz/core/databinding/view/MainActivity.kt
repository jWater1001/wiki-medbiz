package com.medbiz.core.databinding.view

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.navigation.NavigationView
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityMainBinding
import com.medbiz.core.databinding.NavHeaderBinding
import com.medbiz.core.databinding.recyclerview.decoration.ItemDecorationWithSpace
import com.medbiz.core.databinding.viewModel.MainViewModel
import com.medbiz.core.healthdata.BloodPressure
import com.medbiz.core.healthdata.BodyTemperature
import com.medbiz.core.healthdata.Glucose
import com.medbiz.core.healthdata.HealthConstants


class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    var tag = MainActivity::class.java.name

    lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private var accessToken:String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val navHeaderBinding = NavHeaderBinding.bind(binding.navView.getHeaderView(0))
        binding.navView.setNavigationItemSelectedListener(this)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        binding.mainViewModel=viewModel

        binding.contentMain.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.contentMain.recyclerView.adapter = viewModel.adapter
        binding.contentMain.recyclerView.addItemDecoration(ItemDecorationWithSpace(20))

        var fullWidthDP = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        var navDrawerWidthDP = fullWidthDP - 56.0
        binding.navView.layoutParams.width=(navDrawerWidthDP * resources.displayMetrics.density).toInt()
        var toggle = ActionBarDrawerToggle(this, binding.drawerLayout, binding.contentMain.toolbar, 0, 0)
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()


        binding.contentMain.toolBarImage = R.drawable.login_background_01

        viewModel.bloodPressure.observe(this,  Observer { bloodPressure ->
            if(bloodPressure != null) {
                var data = viewModel.adapter.getItem(HealthConstants.BLOOD_PRESSURE) as BloodPressure
                data.dias = bloodPressure.diastolic
                data.sys = bloodPressure.systolic
                viewModel.adapter.notifyDataSetChanged()
            }
        })

        viewModel.glucose.observe(this,  Observer { glucose ->
            if(glucose != null) {
                var data = viewModel.adapter.getItem(HealthConstants.GLUCOSE) as Glucose
                data.glucose = glucose.glucose
                viewModel.adapter.notifyDataSetChanged()
            }
        })

        viewModel.bodyTemperature.observe(this,  Observer { bodyTemperature ->
            if(bodyTemperature != null) {
                var data = viewModel.adapter.getItem(HealthConstants.BODY_TEMPERATURE) as BodyTemperature
                data.bodyTemperature = bodyTemperature.bodyTemperature
                viewModel.adapter.notifyDataSetChanged()
            }
        })

        viewModel.userMe.observe(this, Observer { userMe ->
            if(userMe != null) {
                navHeaderBinding.nickName.text = userMe.userName
                navHeaderBinding.medbizId.text = userMe.userId
            } else {
                navHeaderBinding.nickName.text = resources.getText(R.string.nickName)
                navHeaderBinding.medbizId.text = resources.getText(R.string.addId)
            }
        })
        viewModel.oauthToken.observe(this, Observer { token ->
            accessToken = token?.accessToken
        })

        navHeaderBinding.profileCardView.setOnClickListener { view ->
            var intent = Intent(this, ProfileActivity::class.java)
            (view.context as Activity).startActivityForResult(intent, MainViewModel.REQUEST_EDIT_PROFILE)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean { // Handle item selection
        return when (item.itemId) {
            R.id.goals -> {
                Log.d(tag, "goals")
                true
            }
            R.id.weeklyAnalysis -> {
                Log.d(tag, "weeklyAnalysis")
                true
            }
            R.id.accessory -> {
                Log.d(tag, "accessory")
                true
            }
            R.id.devices -> {
                Log.d(tag, "devices")
                if(accessToken != null) {
                    val intent = Intent(this, MyDeviceActivity::class.java)
                    intent.putExtra("accessToken", accessToken)
                    (this as Activity).startActivity(intent)
                }
                true
            }
            R.id.notification -> {
                Log.d(tag, "notification")
                true
            }
            R.id.questions -> {
                Log.d(tag, "questions")
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


}
package com.medbiz.core.databinding.recyclerview.adapter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.medbiz.core.R
import com.medbiz.core.databinding.view.*
import com.medbiz.core.healthdata.*


class HealthConstantAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var itemList: List<HealthConstants> = listOf()
    override fun getItemCount(): Int {
        return itemList.size
    }

    fun setItemList(itemList: List<HealthConstants>) {
        this.itemList = itemList
        notifyDataSetChanged()
    }

    fun getItem(dataType: Int): HealthConstants? {
        for(item in itemList) {
            if(dataType == item.dataType)
                return item
        }
        return null
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val obj = itemList[position]) {
            is BloodPressure -> {
                (holder as BloodPressureViewHolder).bind(obj)
            }
            is Glucose -> {
                (holder as GlucoseViewHolder).bind(obj)
            }
            is StepCount -> {
                (holder as StepCountViewHolder).bind(obj)
            }
            is BodyTemperature -> {
                (holder as BodyTemperatureViewHolder).bind(obj)
            }
            is Weight -> {
                (holder as WeightViewHolder).bind(obj)
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return itemList[position].dataType
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view: View?
        return when (viewType) {
            HealthConstants.BLOOD_PRESSURE -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_bloodpressure, parent, false)
                BloodPressureViewHolder(view)
            }
            HealthConstants.GLUCOSE -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_glucose, parent, false)
                GlucoseViewHolder(view)
            }
            HealthConstants.STEP_COUNT -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_step_count, parent, false)
                StepCountViewHolder(view)
            }
            HealthConstants.BODY_TEMPERATURE -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_body_temperature, parent, false)
                BodyTemperatureViewHolder(view)
            }
            HealthConstants.WEIGHT -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_weight, parent, false)
                WeightViewHolder(view)
            }
            else -> throw RuntimeException("Non type viewHolder")
        }
    }

    inner class BloodPressureViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val diastolicTextView = itemView.findViewById<TextView>(R.id.diastolic)
        private val systolicTextView = itemView.findViewById<TextView>(R.id.systolic)
        private val button = itemView.findViewById<Button>(R.id.bloodPressureInputButton)
        private val cardView = itemView.findViewById<CardView>(R.id.cardViewBloodPressure)

        fun bind(data: BloodPressure) {
            if(data.dias == 0) diastolicTextView.text = "--"
            else diastolicTextView.text = data.dias.toString()
            if(data.sys == 0)  systolicTextView.text = "--"
            else systolicTextView.text = data.sys.toString()

            button.setOnClickListener {
                var intent = Intent(itemView.context, InputBloodPressureActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
            cardView.setOnClickListener {
                var intent = Intent(itemView.context, DisplayBloodPressureActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
        }
    }

    inner class GlucoseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val glucoseTextView = itemView.findViewById<TextView>(R.id.glucoseValue)
        private val button = itemView.findViewById<Button>(R.id.glucoseInputButton)
        private val cardView = itemView.findViewById<CardView>(R.id.cardViewGlucose)

        fun bind(data: Glucose) {
            if(data.glucose == 0) glucoseTextView.text = "--"
            else glucoseTextView.text = data.glucose.toString()

            button.setOnClickListener {
                var intent = Intent(itemView.context, InputGlucoseActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
            cardView.setOnClickListener {
                var intent = Intent(itemView.context, DisplayGlucoseActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
        }
    }

    inner class StepCountViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val stepCountPieChartView = itemView.findViewById<PieChart>(R.id.stepCountPieChart)
        private val stepCountLineChartView = itemView.findViewById<LineChart>(R.id.stepCountLineChart)

        private var resources =  itemView.context.resources

        fun bind(stepCount: StepCount) {
            makePieChart(step = 55, aimStepCount = 6000)
            makeLineChart(step = listOf(0, 100, 400, 700))
        }

        private fun generateCenterSpannableText(stepCount: Int, aimStepCount: Int): SpannableString {

            var digitStepCount = stepCount.toString().length
            var digitAimStepCount = aimStepCount.toString().length
            val strStepCount = "%" + digitStepCount.toString() + "d\n"
            var strAimStepCount= "/%" + digitAimStepCount.toString() + "d 걸음"
            val s = SpannableString(String.format(strStepCount+strAimStepCount, stepCount, aimStepCount))

            s.setSpan(RelativeSizeSpan(3.0f), 0, digitStepCount+1, 0)
//            s.setSpan(StyleSpan(Typeface.NORMAL), 14, s.length - 15, 0)
//            s.setSpan(ForegroundColorSpan(Color.GRAY), 14, s.length - 15, 0)
            return s
        }

        private fun makePieChart(step:Int, aimStepCount: Int) {

            val s = generateCenterSpannableText(step, aimStepCount)

            val yValues = ArrayList<PieEntry>()
            yValues.add(PieEntry(step.toFloat()))
            yValues.add(PieEntry(aimStepCount.toFloat()))

            val dataSet = PieDataSet(yValues, "")
            dataSet.setColors(*ColorTemplate.MATERIAL_COLORS)
            val data = PieData(dataSet)
            data.setDrawValues(false)

            stepCountPieChartView.setUsePercentValues(true)
            stepCountPieChartView.description.isEnabled=false
            stepCountPieChartView.isRotationEnabled = false
            stepCountPieChartView.setTouchEnabled(false)

            stepCountPieChartView.setExtraOffsets(5f,5f,5f,5f)

            stepCountPieChartView.centerText = s
            stepCountPieChartView.isDrawHoleEnabled = true
            stepCountPieChartView.setHoleColor(Color.WHITE)
            stepCountPieChartView.layoutParams.height = resources.displayMetrics.widthPixels / 2

            stepCountPieChartView.holeRadius *= 1.4f
            stepCountPieChartView.transparentCircleRadius = stepCountPieChartView.holeRadius


            stepCountPieChartView.animateY(2000, Easing.EaseInOutCubic) //애니메이션
            stepCountPieChartView.legend.isEnabled = false
            stepCountPieChartView.data = data
        }
        private fun makeLineChart(step: List<Int>) {

        }
    }

    inner class BodyTemperatureViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val bodyTemperatureTextView = itemView.findViewById<TextView>(R.id.bodyTemperatureValue)
        private val button = itemView.findViewById<Button>(R.id.bodyTemperatureButton)
        private val cardView = itemView.findViewById<CardView>(R.id.cardViewBodyTemperature)

        fun bind(data: BodyTemperature) {
            if(data.bodyTemperature == 0.0) bodyTemperatureTextView.text = "--"
            else bodyTemperatureTextView.text = data.bodyTemperature.toString()

            button.setOnClickListener {
                var intent = Intent(itemView.context, InputBodyTemperatureActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
            cardView.setOnClickListener {
                var intent = Intent(itemView.context, DisplayBodyTemperatureActivity::class.java)
                (itemView.context as Activity).startActivity(intent)
            }
        }


    }

    inner class WeightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val weightTextView = itemView.findViewById<TextView>(R.id.weightValue)
        private val button = itemView.findViewById<Button>(R.id.weightButton)

        fun bind(weight: Weight) {
            weightTextView.text = weight.weight.toString()
            button.setOnClickListener {
            }
        }
    }
}
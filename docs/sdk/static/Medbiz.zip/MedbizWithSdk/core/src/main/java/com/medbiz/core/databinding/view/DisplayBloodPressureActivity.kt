package com.medbiz.core.databinding.view

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityDisplayBloodPressureBinding
import com.medbiz.core.databinding.adapter.BloodPressurePagerAdapter
import com.medbiz.core.databinding.viewModel.DisplayBloodPressureViewModel

class DisplayBloodPressureActivity : AppCompatActivity() {
    private lateinit var viewModel: DisplayBloodPressureViewModel
    lateinit var binding: ActivityDisplayBloodPressureBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_display_blood_pressure)
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.back)
        }
        binding.viewPager.adapter = BloodPressurePagerAdapter(supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
        binding.tabLayout.setupWithViewPager(binding.viewPager)
    }
}

package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.medbiz.core.R
import com.medbiz.core.databinding.view.LoginActivity
import com.medbiz.core.databinding.view.MainActivity
import com.medbiz.core.singleton.Preferences
import com.medbiz.sdk.openapi.Password
import com.medbiz.sdk.openapi.UserMe
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.android.synthetic.main.dialog_login.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LoginIntroViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = LoginIntroViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val oAuthTokenRepository = OAuthTokenRepository(application)
    private val userMeRepository = UserMeRepository(application)
//    fun onStartLoginButtonClick(view: View) {
//        var intent = Intent(view.context, LoginActivity::class.java)
//        startActivity(view.context, intent, null)
//        (view.context as Activity).finish()
//    }
    fun onStartMainButtonClick(view: View) {
        var intent = Intent(view.context, MainActivity::class.java)
        startActivity(view.context, intent, null)
        (view.context as Activity).finish()
    }

    fun onStartLoginButtonClick(view: View) {
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_login, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        mAlertDialog.window?.apply {
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }

        mDialogView.loginButton.setOnClickListener {
            val userName = mDialogView.inputEditTextUserName.text.toString()
            val password = mDialogView.inputEditTextPassword.text.toString()

            scope.launch {
                Preferences.savedId = userName
                Preferences.savedPwd = password
                val res = Password(oAuthTokenRepository).requestAccessToken(userName, password)
                if(res != null) {
                    Toast.makeText(getApplication(), "Login Success", Toast.LENGTH_LONG).show()
                    UserMe(userMeRepository).getUserMe("Bearer " + res.accessToken)
                    mAlertDialog.dismiss()

                    val intent = Intent(view.context, MainActivity::class.java)
                    startActivity(view.context, intent, null)
                    (view.context as Activity).finish()
                } else {
                    mDialogView.apply {
                        inputEditTextUserName.setText("")
                        inputEditTextPassword.setText("")
                    }
                }
            }
        }

        mDialogView.cancelButton.setOnClickListener {
            mDialogView.inputEditTextUserName.setText("")
            mDialogView.inputEditTextPassword.setText("")
            mAlertDialog.dismiss()
        }
    }
}
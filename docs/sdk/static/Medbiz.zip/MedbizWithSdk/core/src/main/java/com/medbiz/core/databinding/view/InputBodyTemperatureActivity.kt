package com.medbiz.core.databinding.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityInputBloodPressureBinding
import com.medbiz.core.databinding.ActivityInputBodyTemperatureBinding
import com.medbiz.core.databinding.viewModel.InputBloodPressureViewModel
import com.medbiz.core.databinding.viewModel.InputBodyTemperatureViewModel

class InputBodyTemperatureActivity : AppCompatActivity() {
    var tag = InputBodyTemperatureActivity::class.java.name

    lateinit var binding: ActivityInputBodyTemperatureBinding
    private lateinit var viewModel: InputBodyTemperatureViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_input_body_temperature)
        viewModel = ViewModelProvider(this).get(InputBodyTemperatureViewModel::class.java)
        binding.viewModel = viewModel

        binding.bodyTemperatureRecyclerView.apply {
            var layout = LinearLayoutManager(this.context)
            var snapHelper = LinearSnapHelper()
            layout.orientation = RecyclerView.HORIZONTAL
            this.layoutManager = layout
            this.adapter = viewModel.bodyTemperatureAdapter
            snapHelper.attachToRecyclerView(this)
            this.scrollToPosition(11)
            this.smoothScrollBy(1,0)
            this.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var centerView = snapHelper.findSnapView(layout)
                    if(null != centerView) {
                        var position = layout.getPosition(centerView)
                        viewModel.pickeredBodyTemperature.postValue(viewModel.bodyTemperatureAdapter.getItemViewType(position).toDouble())
                    }
                }
            })
        }

        binding.pickeredBodyTemperatureValuePoint.bringToFront()

        viewModel.pickeredBodyTemperature.observe(this,  Observer {
            bodyTemperature -> binding.pickeredBodyTemperatureValue.text = (bodyTemperature / 10.0).toString()
        })


        viewModel.localeTime.observe(this,  Observer {
            time -> binding.dateTimeButton.text = time
        })

        binding.pillUsageDropdown.setText(viewModel.measurementContextInfo[0])
        binding.pillUsageDropdown.setAdapter(ArrayAdapter(this, R.layout.pill_usage_dropdown_item, viewModel.measurementContextInfo))
        binding.pillUsageDropdown.onItemClickListener = AdapterView.OnItemClickListener {
            view , _ , position, _ ->
            viewModel.measurementContext.postValue(view.getItemAtPosition(position).toString())
        }

        binding.memoEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                viewModel.memo.postValue(p0.toString())
            }
        })
    }
}

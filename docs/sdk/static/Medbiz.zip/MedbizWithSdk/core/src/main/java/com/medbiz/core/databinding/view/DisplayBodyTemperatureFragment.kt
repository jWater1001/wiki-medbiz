package com.medbiz.core.databinding.view

import android.bluetooth.BluetoothGattDescriptor
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.FragmentDisplayBodyTemperatureBinding
import com.medbiz.core.databinding.viewModel.DisplayBodyTemperatureViewModel
import java.text.SimpleDateFormat
import java.util.*


class DisplayBodyTemperatureFragment : Fragment() {
    private lateinit var viewModel: DisplayBodyTemperatureViewModel
    lateinit var binding: FragmentDisplayBodyTemperatureBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_display_body_temperature, container,false)

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(DisplayBodyTemperatureViewModel::class.java)
        binding.viewModel = viewModel

        viewModel.bodyTemperature.observe(viewLifecycleOwner,  Observer { data ->
            if(data == null) {
                binding.noDataTextView.isVisible = true
                binding.latestMeasuredBodyTemperature.isVisible = false
                binding.latestMeasuredTime.isVisible = false
            } else {
                binding.noDataTextView.isVisible = false
                binding.latestMeasuredBodyTemperature.isVisible = true
                binding.latestMeasuredTime.isVisible = true

                val bodyTemperatureValue = SpannableString(data.bodyTemperature.toString() + "°C")

                bodyTemperatureValue.setSpan(RelativeSizeSpan(0.3f), bodyTemperatureValue.length-2, bodyTemperatureValue.length, 0)
                binding.latestMeasuredBodyTemperature.text = bodyTemperatureValue
                binding.latestMeasuredTime.text = SimpleDateFormat("yyyy년 MM월 dd일(E) HH:mm").format(Date(data.timeStamp))
            }
        })
    }
    override fun onResume() {
        super.onResume()
        viewModel.bindService(activity!!.application)
    }
    override fun onStop() {
        super.onStop()
        viewModel.unbindService(activity!!.application)
    }
}

package com.medbiz.core.databinding.model.repository

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.databinding.model.database.AppDB
import com.medbiz.core.databinding.model.entity.BloodPressureEntity

class BloodPressureRepository(application: Application) {
    private var bloodPressureDao = AppDB.getInstance(application)!!.bloodPressureDao()
    fun getDBInstance(): AppDB.Companion {
        return AppDB
    }

    suspend fun getAll(): List<BloodPressureEntity> {
        return bloodPressureDao.getAll()
    }

    fun getLatestMeasuredData(): LiveData<BloodPressureEntity> {
        return bloodPressureDao.getLatestMeasuredData()
    }

    suspend fun insert(bloodPressureEntity: BloodPressureEntity) {
        bloodPressureDao.insert(bloodPressureEntity)
    }

    suspend fun deleteAll() {
        bloodPressureDao.deleteAll()
    }

    suspend fun delete(bloodPressureEntity: BloodPressureEntity) {
        bloodPressureDao.delete(bloodPressureEntity)
    }

    suspend fun update(bloodPressureEntity: BloodPressureEntity) {
        bloodPressureDao.update(bloodPressureEntity)
    }
}


package com.medbiz.core.databinding.recyclerview.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.medbiz.core.R
import com.medbiz.sdk.room.entity.MyDeviceEntity


class MyDeviceAdapter : RecyclerView.Adapter<MyDeviceAdapter.ViewHolder>() {
    val tag =  MyDeviceAdapter::class.java.name
    private var itemList: List<MyDeviceEntity> = listOf()

    override fun getItemCount(): Int {
        return itemList.size
    }

    fun setItemList(itemList: List<MyDeviceEntity>) {
        this.itemList = itemList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_my_device, parent, false)
        return ViewHolder(view)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val image = itemView.findViewById<ImageView>(R.id.deviceImage)
        private val nickName = itemView.findViewById<TextView>(R.id.deviceNickName)
        fun bind(item: MyDeviceEntity) {
            Glide.with(itemView.context).load(item.modelImageUri).placeholder(R.drawable.no_device).into(image)
            nickName.text = item.deviceNickname
        }
    }
}

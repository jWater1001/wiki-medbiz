package com.medbiz.core.healthdata

class StepCount: HealthConstants() {
    val healthDataType = "com.medbiz.core.healthdata.StepCount"
    var StepCount = 0

    init {
        super.dataType = STEP_COUNT
    }

}

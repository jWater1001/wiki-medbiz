package com.medbiz.core.databinding.viewModel

import android.app.Application
import android.util.Log
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.github.mikephil.charting.charts.PieChart
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.repository.BloodPressureRepository
import com.medbiz.core.databinding.model.repository.BodyTemperatureRepository
import com.medbiz.core.databinding.model.repository.GlucoseRepository
import com.medbiz.core.healthdata.*
import com.medbiz.core.databinding.recyclerview.adapter.HealthConstantAdapter
import com.medbiz.core.singleton.Preferences
import com.medbiz.sdk.openapi.Password
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch


class MainViewModel (application: Application) : AndroidViewModel(application) {
    private val tag = MainViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val bloodPressureRepository = BloodPressureRepository(application)
    private val glucoseRepository = GlucoseRepository(application)
    private val oAuthTokenRepository = OAuthTokenRepository(application)
    private val bodyTemperatureRepository = BodyTemperatureRepository(application)
    private val userMeRepository = UserMeRepository(application)
    val adapter = HealthConstantAdapter()
    var pieChart: PieChart? = null
    var bloodPressure = bloodPressureRepository.getLatestMeasuredData()
    var glucose = glucoseRepository.getLatestMeasuredData()
    var bodyTemperature = bodyTemperatureRepository.getLatestMeasuredData()
    var userMe = userMeRepository.getUserMeFromDB()
    var oauthToken = oAuthTokenRepository.getOAuthTokenFromDB()

    var list = listOf(
            BloodPressure(),
            Glucose(),
            BodyTemperature(),
            StepCount(),
            Weight()
    )

    init {
        scope.launch {
            adapter.setItemList(list)

            val tokenFromDB = oAuthTokenRepository.getSize()
            // tokenFromDB == null 이면, 사용자 로그인 없이 사용
            if(tokenFromDB == 0) {

            } else {
                // Preferences에 ID. PW 저장되어 있으면 토큰 발행 요청
                if(Preferences.savedId?.isNotBlank() as Boolean && Preferences.savedPwd?.isNotBlank() as Boolean) {
                    val token = Password(oAuthTokenRepository).requestAccessToken(Preferences.savedId as String, Preferences.savedPwd as String)
                    Log.d(tag, "MainActivity에서 새로발급받은 토큰은 ${token.toString()} 입니다.")
                }
            }
        }
    }

    companion object {
        const val REQUEST_EDIT_PROFILE = 100
        const val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 200
    }
}
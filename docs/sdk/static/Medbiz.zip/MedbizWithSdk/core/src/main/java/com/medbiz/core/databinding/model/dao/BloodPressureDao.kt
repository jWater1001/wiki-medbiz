package com.medbiz.core.databinding.model.dao

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.*
import com.medbiz.core.databinding.model.entity.BloodPressureEntity

@Dao
interface BloodPressureDao {
    @Query("SELECT * FROM blood_pressure")
    suspend fun getAll(): List<BloodPressureEntity>

    @Query("SELECT * FROM blood_pressure ORDER BY timeStamp DESC limit 1")
    fun getLatestMeasuredData(): LiveData<BloodPressureEntity>

    @Query("DELETE FROM blood_pressure")
    suspend fun deleteAll()

    @Insert
    suspend fun insert(vararg bloodPressureEntity: BloodPressureEntity)

    @Delete
    suspend fun delete(bloodPressureEntity: BloodPressureEntity)

    @Update
    suspend fun update(bloodPressureEntity: BloodPressureEntity)
}
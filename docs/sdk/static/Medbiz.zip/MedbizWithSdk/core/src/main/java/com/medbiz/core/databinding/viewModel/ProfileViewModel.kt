package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.R
import com.medbiz.core.singleton.Preferences
import com.medbiz.sdk.openapi.Password
import com.medbiz.sdk.openapi.UserMe
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.android.synthetic.main.dialog_height.view.*
import kotlinx.android.synthetic.main.dialog_birthday.view.*
import kotlinx.android.synthetic.main.dialog_gender.view.*
import kotlinx.android.synthetic.main.dialog_gender.view.nextOrConfirmButton
import kotlinx.android.synthetic.main.dialog_login.view.*
import kotlinx.android.synthetic.main.dialog_login.view.cancelButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.*
import kotlin.math.min

class ProfileViewModel(application: Application) : AndroidViewModel(application) {
    private val totalUserInfoCount = 4
    private val tag = ProfileViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val oAuthTokenRepository = OAuthTokenRepository(application)
    private val userMeRepository = UserMeRepository(application)
    private var userInfoCounter = totalUserInfoCount
    lateinit var token: LiveData<OAuthTokenEntity>

    var userMe = userMeRepository.getUserMeFromDB()

    var userGender = MutableLiveData<String>()
    var userBirthday = MutableLiveData<String>()
    var userHeight = MutableLiveData<String>()
    var userWeight = MutableLiveData<String>()


    init {
        if(Preferences.userInfoCompleteFlag) {
            if (Preferences.gender != null) userGender.postValue(Preferences.gender)
            if (Preferences.birthday != null) userBirthday.postValue(Preferences.birthday)
            if (Preferences.height != null) userHeight.postValue(Preferences.height)
            if (Preferences.weight != null) userWeight.postValue(Preferences.weight)
        }
    }

    fun onStartLoginButtonClick(view: View) {
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_login, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        mAlertDialog.window?.apply {
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }

        mDialogView.loginButton.setOnClickListener {
            val userName = mDialogView.inputEditTextUserName.text.toString()
            val password = mDialogView.inputEditTextPassword.text.toString()

            scope.launch {
                Preferences.savedId = userName
                Preferences.savedPwd = password
                val res = Password(oAuthTokenRepository).requestAccessToken(userName, password)
                if(res != null) {
                    Toast.makeText(getApplication(), "Login Success", Toast.LENGTH_LONG).show()
                    UserMe(userMeRepository).getUserMe("Bearer " + res.accessToken)
                    Preferences.apply {
                        gender = null
                        birthday = null
                        height = null
                        weight = null
                        userInfoCompleteFlag = false
                    }
                    mAlertDialog.dismiss()
                    (view.context as Activity).finish()
                } else {
                    mDialogView.apply {
                        inputEditTextUserName.setText("")
                        inputEditTextPassword.setText("")
                    }
                }
            }
        }

        mDialogView.cancelButton.setOnClickListener {
            mDialogView.inputEditTextUserName.setText("")
            mDialogView.inputEditTextPassword.setText("")
            mAlertDialog.dismiss()
        }
    }

    fun setGenderButtonClick(view: View) {
        var gender: String? = null
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_gender, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        if(Preferences.userInfoCompleteFlag || userInfoCounter == 1) mDialogView.nextOrConfirmButton.text = "확인"


        mAlertDialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }

        mDialogView.maleRadioButton.setOnClickListener {
            gender = "MALE"
            mDialogView.femaleRadioButton.isChecked = false
        }

        mDialogView.femaleRadioButton.setOnClickListener {
            gender = "FEMALE"
            mDialogView.maleRadioButton.isChecked = false
        }

        mDialogView.nextOrConfirmButton.setOnClickListener {
            if(gender == null) {
                Toast.makeText(view.context, "성별을 선택해주세요", Toast.LENGTH_SHORT).show()
            } else {
                Preferences.gender = gender
                userGender.postValue(Preferences.gender)
                if(--userInfoCounter == 0 && !Preferences.userInfoCompleteFlag) postValue()
                mAlertDialog.dismiss()
            }
        }

        mDialogView.cancelButton.setOnClickListener {
            if(!Preferences.userInfoCompleteFlag) {
                userInfoCounter = totalUserInfoCount
            }
            mAlertDialog.dismiss()
        }
    }

    fun setBirthdayButtonClick(view: View) {
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_birthday, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()
        val minCalendar = Calendar.getInstance()
        val today = Calendar.getInstance()

        if(Preferences.userInfoCompleteFlag || userInfoCounter == 1) mDialogView.nextOrConfirmButton.text = "확인"

        // SimpleDateFormat("yyyy", Locale.getDefault()).format(today.time).toInt(),
        mDialogView.datePicker.init(1985,6,15,null)

        minCalendar.set(1920, 0, 1)
        mDialogView.datePicker.minDate = minCalendar.timeInMillis

        mDialogView.datePicker.maxDate = today.timeInMillis

        mAlertDialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }

        mDialogView.nextOrConfirmButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            calendar.set(mDialogView.datePicker.year,
                    mDialogView.datePicker.month,
                    mDialogView.datePicker.dayOfMonth,
                    0, 0, 0)
            Preferences.birthday = calendar.timeInMillis.toString()
            userBirthday.postValue(Preferences.birthday)
            if(--userInfoCounter == 0 && !Preferences.userInfoCompleteFlag) postValue()
            mAlertDialog.dismiss()
        }

        mDialogView.cancelButton.setOnClickListener {
            if(!Preferences.userInfoCompleteFlag) {
                userInfoCounter = totalUserInfoCount
            }
            mAlertDialog.dismiss()
        }
    }

    fun setHeightButtonClick(view: View) {
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_height, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        if(Preferences.userInfoCompleteFlag || userInfoCounter == 1) mDialogView.nextOrConfirmButton.text = "확인"

        mDialogView.numberPicker1.apply{
            maxValue = 250
            minValue = 0
            value = 165
        }


        mDialogView.numberPicker2.apply{
            maxValue = 9
            minValue = 0
            value = 5
        }

        mDialogView.nextOrConfirmButton.setOnClickListener {
            val height = mDialogView.numberPicker1.value + mDialogView.numberPicker2.value * 0.1
            Preferences.height = height.toString()
            userHeight.postValue(Preferences.height)
            if(--userInfoCounter == 0 && !Preferences.userInfoCompleteFlag) postValue()
            mAlertDialog.dismiss()
        }

        mDialogView.cancelButton.setOnClickListener {
            if(!Preferences.userInfoCompleteFlag) {
                userInfoCounter = totalUserInfoCount
            }
            mAlertDialog.dismiss()
        }
    }

    fun setWeightButtonClick(view: View) {
        val mDialogView = LayoutInflater.from(view.context).inflate(R.layout.dialog_weight, null)
        val mBuilder = AlertDialog.Builder(view.context).setView(mDialogView)
        val mAlertDialog = mBuilder.show()

        if(Preferences.userInfoCompleteFlag || userInfoCounter == 1) mDialogView.nextOrConfirmButton.text = "확인"

        mDialogView.numberPicker1.apply {
            maxValue = 200
            minValue = 0
            value = 60
        }


        mDialogView.numberPicker2.apply {
            maxValue = 9
            minValue = 0
            value = 5
        }

        mDialogView.nextOrConfirmButton.setOnClickListener {
            val weight = mDialogView.numberPicker1.value + mDialogView.numberPicker2.value * 0.1
            Preferences.weight = weight.toString()
            userWeight.postValue(Preferences.weight)
            if(--userInfoCounter == 0 && !Preferences.userInfoCompleteFlag) postValue()
            mAlertDialog.dismiss()
        }

        mDialogView.cancelButton.setOnClickListener {
            if(!Preferences.userInfoCompleteFlag) {
                userInfoCounter = totalUserInfoCount
            }
            mAlertDialog.dismiss()
        }
    }

    fun postValue() {
        Preferences.userInfoCompleteFlag = true
        userGender.postValue(Preferences.gender)
        userBirthday.postValue(Preferences.birthday)
        userHeight.postValue(Preferences.height)
        userWeight.postValue(Preferences.weight)
    }
}
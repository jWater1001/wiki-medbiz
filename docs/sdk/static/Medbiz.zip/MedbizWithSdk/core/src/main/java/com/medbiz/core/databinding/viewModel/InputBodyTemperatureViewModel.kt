package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.Application
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.databinding.model.entity.BodyTemperatureEntity
import com.medbiz.core.databinding.model.repository.BloodPressureRepository
import com.medbiz.core.databinding.model.repository.BodyTemperatureRepository
import com.medbiz.core.databinding.recyclerview.adapter.BodyTemperaturePickerAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class InputBodyTemperatureViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = InputBodyTemperatureViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val repository = BodyTemperatureRepository(application)
    var pickeredBodyTemperature = MutableLiveData<Double>()
    var measurementContextInfo = arrayOf("이마", "겨드랑이", "관자놀이")
    var measurementContext = MutableLiveData<String>()
    var memo = MutableLiveData<String>()
    val bodyTemperatureAdapter = BodyTemperaturePickerAdapter()
    var localeTime = MutableLiveData<String>()
    private var localeTimeDetail = Date().time

    init {
        localeTime.postValue(SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분", Locale.getDefault()).format(Date()))
        pickeredBodyTemperature.postValue(36.5)
        val base: MutableList<Double> = mutableListOf()

        for(i in 345..425)
            base.add(i/10.0)

        bodyTemperatureAdapter.setItemList(base)
        bodyTemperatureAdapter.setMax(42.1)
    }

    fun onClickSavedButton(view: View) {
        var sdf = SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분")
        var timestamp = sdf.parse(localeTime.value).time

        var data = BodyTemperatureEntity(
                bodyTemperature = (pickeredBodyTemperature.value)!!/(10.0),
                context = measurementContext.value,
                timeStamp = localeTimeDetail,
                memo = memo.value
        )
        scope.launch {
            repository.insert(data)
        }
        (view.context as Activity).onBackPressed()
    }

    fun onClickCanceledButton(view: View) {
        (view.context as Activity).onBackPressed()
    }
}
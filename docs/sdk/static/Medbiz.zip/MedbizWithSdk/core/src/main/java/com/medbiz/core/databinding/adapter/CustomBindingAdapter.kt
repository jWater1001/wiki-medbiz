package com.medbiz.core.databinding.adapter

import android.util.DisplayMetrics
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.medbiz.core.R


@BindingAdapter("glideImage")
fun bindingImage(view: ImageView, res: Int?) {
    Glide.with(view.context)
            .load(res)
            .centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(view)
}


@BindingAdapter("toolBarImage")
fun bindingToolBarImage(view: ImageView, res: Int?) {
    Glide.with(view.context)
            .load(res)
            .centerCrop()
            .into(view)
}

@BindingAdapter("profileSlideImage")
fun bindingProfileSlideImage(view: ImageView, res: Int?) {
    Glide.with(view.context)
            .load(R.drawable.profile_3)
            .centerCrop()
            .into(view)
}

@BindingAdapter("userProfileImage")
fun bindingUserProfileImage(view: ImageView, res: Int?) {
    Glide.with(view.context)
            .load(res)
            .into(view)
}


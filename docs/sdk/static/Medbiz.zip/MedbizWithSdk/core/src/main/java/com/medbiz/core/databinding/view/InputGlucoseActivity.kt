package com.medbiz.core.databinding.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityInputGlucoseBinding
import com.medbiz.core.databinding.viewModel.InputGlucoseViewModel

class InputGlucoseActivity : AppCompatActivity() {
    var tag = InputGlucoseActivity::class.java.name

    lateinit var binding: ActivityInputGlucoseBinding
    private lateinit var viewModel: InputGlucoseViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_input_glucose)
        viewModel = ViewModelProvider(this).get(InputGlucoseViewModel::class.java)
        binding.viewModel = viewModel

        binding.glucoseRecyclerView.apply {
            var layout = LinearLayoutManager(this.context)
            var snapHelper = LinearSnapHelper()
            layout.orientation = RecyclerView.HORIZONTAL
            this.layoutManager = layout
            this.adapter = viewModel.glucoseAdapter
            snapHelper.attachToRecyclerView(this)
            this.scrollToPosition(80)
            this.smoothScrollBy(1,0)
            this.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var centerView = snapHelper.findSnapView(layout)
                    if(null != centerView) {
                        var position = layout.getPosition(centerView)
                        viewModel.pickeredGlucose.postValue(viewModel.glucoseAdapter.getItemViewType(position))
                    }
                }
            })
        }

        binding.glucoseContextMealRecyclerView.apply {
            var layout = LinearLayoutManager(this.context)
            layout.orientation = RecyclerView.HORIZONTAL
            this.layoutManager = layout
            this.adapter = viewModel.glucoseContextMealAdapter
        }

        binding.pickeredGlucoseValuePoint.bringToFront()

        viewModel.pickeredGlucose.observe(this,  Observer {
            glucose -> binding.pickeredGlucoseValue.text = glucose.toString()
        })

        viewModel.localeTime.observe(this,  Observer {
            time -> binding.dateTimeButton.text = time
        })

        binding.insulinEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if(p1 > 1 && p0.toString().toDouble() > 100) {
                    with(binding) {
                        insulinEditText.setText("100")
                        insulinEditText.selectAll()
                        insulinEditText.error = "0.1 - 100 사이의 숫자를 입력하세요"
                    }
                }
            }
        })
        binding.insulinEditText.setOnEditorActionListener(TextView.OnEditorActionListener {
            v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                if (event == null || !event.isShiftPressed) {
                    var text = v.text.toString()
                    var value = 0.0
                    value = if (text.isBlank()) {
                        0.1
                    } else {
                        text.toDouble()
                    }
                    if (value < 0.1) {
                        binding.insulinEditText.setText("0.1")
                        binding.insulinEditText.selectAll()
                        binding.insulinEditText.error = "0.1 - 100 사이의 숫자를 입력하세요"
                        return@OnEditorActionListener true // consume.
                    } else {
                        binding.insulinEditText.error = null
                        viewModel.insulin.postValue(binding.insulinEditText.text.toString().toDouble())
                        return@OnEditorActionListener false // consume.
                    }

                }
            }
            false // pass on to other listeners.
        })

        binding.pillUsageDropdown.setText(viewModel.pillUsageInfo[0])
        binding.pillUsageDropdown.setAdapter(ArrayAdapter(this, R.layout.pill_usage_dropdown_item, viewModel.pillUsageInfo))
        binding.pillUsageDropdown.onItemClickListener = AdapterView.OnItemClickListener {
            view , _ , position, _ ->
            viewModel.pillUsage.postValue(view.getItemAtPosition(position).toString())
        }

        binding.memoEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                viewModel.memo.postValue(p0.toString())
            }
        })
    }
}

package com.medbiz.core.databinding.model.database

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.medbiz.core.databinding.model.dao.BloodPressureDao
import com.medbiz.core.databinding.model.dao.BodyTemperatureDao
import com.medbiz.core.databinding.model.dao.GlucoseDao
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.entity.BodyTemperatureEntity
import com.medbiz.core.databinding.model.entity.GlucoseEntity

@Database(entities = [
    BloodPressureEntity::class,
    GlucoseEntity::class,
    BodyTemperatureEntity::class], version = 1, exportSchema = false)
abstract class AppDB: RoomDatabase() {
    abstract fun bloodPressureDao(): BloodPressureDao
    abstract fun glucoseDao(): GlucoseDao
    abstract fun bodyTemperatureDao(): BodyTemperatureDao

    companion object {
        private var INSTANCE: AppDB? = null

        fun getInstance(context: Context): AppDB? {
            if (INSTANCE == null) {
                synchronized(AppDB::class) {
                    Log.d(AppDB::class.java.name, "AppDB 생성")
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            AppDB::class.java, "app.db")
                            .fallbackToDestructiveMigrationOnDowngrade().build()
                    Log.d(AppDB::class.java.name, "AppDB Instance 생성")
                }
            }
            return INSTANCE
        }

        fun destroyInstance() {
            INSTANCE = null
            Log.d(AppDB::class.java.name, "AppDB Instance 삭제")
        }
    }
}
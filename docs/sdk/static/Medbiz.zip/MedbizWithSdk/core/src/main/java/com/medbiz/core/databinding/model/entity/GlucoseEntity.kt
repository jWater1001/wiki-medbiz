package com.medbiz.core.databinding.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "glucose")
data class GlucoseEntity(
        @ColumnInfo(name = "sequence") var sequence: Long?,
        @ColumnInfo(name = "glucose") var glucose: Int,
        @ColumnInfo(name = "contextMeal") var contextMeal: String?,
        @ColumnInfo(name = "insulin") var insulin: Double?,
        @ColumnInfo(name = "timeStamp") var timeStamp: Long,
        @ColumnInfo(name = "pill") var pill: String?,
        @ColumnInfo(name = "memo") var memo: String?
) {
    @PrimaryKey(autoGenerate = true) var id: Int? = null

    override fun toString(): String {
        return "GlucoseEntity(sequence=$sequence, glucose=$glucose, contextMeal=$contextMeal, insulin=$insulin, timeStamp=$timeStamp, pill=$pill, memo=$memo, id=$id)"
    }
}
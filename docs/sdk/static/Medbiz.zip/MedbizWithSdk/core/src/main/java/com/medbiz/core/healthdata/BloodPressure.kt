package com.medbiz.core.healthdata

class BloodPressure: HealthConstants()  {
    val healthDataType = "com.medbiz.core.healthdata.bloodPressure"
    var dias: Int = 0
    var sys: Int = 0

    init {
        super.dataType = BLOOD_PRESSURE
    }
}
package com.medbiz.core.databinding.recyclerview.adapter

import android.graphics.Color
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.android.material.textfield.TextInputEditText
import com.medbiz.core.R
import com.medbiz.core.healthdata.*


class HorizontalPickerAdapter : RecyclerView.Adapter<HorizontalPickerAdapter.ViewHolder>() {
    private var max = 301
    private var itemList: List<Int> = listOf()
    override fun getItemCount(): Int {
        return itemList.size
    }

    fun setMax(max: Int){
        this.max=max
    }
    fun setItemList(itemList: List<Int>) {
        this.itemList = itemList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(itemList[position])
    }

    override fun getItemViewType(position: Int): Int {
        return itemList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_horizontal_picker, parent, false)
        return ViewHolder(view)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val systolicValueText = itemView.findViewById<TextView>(R.id.systolicValueText)

        fun bind(value: Int) {
            if(value % 5 == 0 && value < max) {
                systolicValueText.text = value.toString()
            }
        }
    }
}
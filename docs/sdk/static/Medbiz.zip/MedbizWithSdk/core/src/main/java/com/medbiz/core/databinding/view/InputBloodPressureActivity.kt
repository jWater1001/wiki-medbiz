package com.medbiz.core.databinding.view

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView.OnEditorActionListener
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityInputBloodPressureBinding
import com.medbiz.core.databinding.viewModel.InputBloodPressureViewModel


class InputBloodPressureActivity : AppCompatActivity() {
    var tag = InputBloodPressureActivity::class.java.name

    lateinit var binding: ActivityInputBloodPressureBinding
    private lateinit var viewModel: InputBloodPressureViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_input_blood_pressure)
        viewModel = ViewModelProvider(this).get(InputBloodPressureViewModel::class.java)
        binding.viewModel = viewModel

        binding.systolicRecyclerView.apply {
            var layout = LinearLayoutManager(this.context)
            var snapHelper = LinearSnapHelper()
            layout.orientation = RecyclerView.HORIZONTAL
            this.layoutManager = layout
            this.adapter = viewModel.systolicAdapter
            snapHelper.attachToRecyclerView(this)
            this.scrollToPosition(41)
            this.smoothScrollBy(1,0)
            this.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var centerView = snapHelper.findSnapView(layout)
                    if(null != centerView) {
                        var position = layout.getPosition(centerView)
                        viewModel.pickeredSystolic.postValue(viewModel.systolicAdapter.getItemViewType(position))
                    }
                }
            })
        }

        binding.pickeredSystolicValuePoint.bringToFront()

        viewModel.pickeredSystolic.observe(this,  Observer {
            systolic -> binding.pickeredSystolicValue.text = systolic.toString()
        })

        binding.diastolicRecyclerView.apply {
            var layout = LinearLayoutManager(this.context)
            var snapHelper = LinearSnapHelper()
            layout.orientation = RecyclerView.HORIZONTAL
            this.layoutManager = layout
            this.adapter = viewModel.diastolicAdapter
            snapHelper.attachToRecyclerView(this)
            this.scrollToPosition(81)
            this.smoothScrollBy(1,0)
            this.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    var centerView = snapHelper.findSnapView(layout)
                    if(null != centerView) {
                        var position = layout.getPosition(centerView)
                        viewModel.pickeredDiastolic.postValue(viewModel.diastolicAdapter.getItemViewType(position))
                    }
                }
            })
        }

        binding.pickeredDiastolicValuePoint.bringToFront()

        viewModel.pickeredDiastolic.observe(this,  Observer {
            diastolic -> binding.pickeredDiastolicValue.text = diastolic.toString()
        })

        viewModel.localeTime.observe(this,  Observer {
            time -> binding.dateTimeButton.text = time
        })

        binding.pulseRateEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if(p1 > 1 && p0.toString().toInt() > 300) {
                    with(binding) {
                        pulseRateEditText.setText("300")
                        pulseRateEditText.selectAll()
                        pulseRateEditText.error = "15 - 300 사이의 숫자를 입력하세요"
                    }
                }
            }
        })
        binding.pulseRateEditText.setOnEditorActionListener( OnEditorActionListener {
            v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_NEXT) {
                if (event == null || !event.isShiftPressed) {
                    var text = v.text.toString()
                    var value = 0
                    value = if (text.isBlank()) {
                        0
                    } else {
                        text.toInt()
                    }
                    if(value < 15) {
                        binding.pulseRateEditText.setText("15")
                        binding.pulseRateEditText.selectAll()
                        binding.pulseRateEditText.error = "15 - 300 사이의 숫자를 입력하세요"
                        return@OnEditorActionListener true // consume.
                    } else {
                        binding.pulseRateEditText.error = null
                        viewModel.pulse.postValue(binding.pulseRateEditText.text.toString().toInt())
                        return@OnEditorActionListener false // consume.
                    }

                }
            }
            false // pass on to other listeners.
        })

        binding.pillUsageDropdown.setText(viewModel.pillUsageInfo[0])
        binding.pillUsageDropdown.setAdapter(ArrayAdapter(this, R.layout.pill_usage_dropdown_item, viewModel.pillUsageInfo))
        binding.pillUsageDropdown.onItemClickListener = AdapterView.OnItemClickListener {
            view , _ , position, _ ->
            viewModel.pillUsage.postValue(view.getItemAtPosition(position).toString())
        }

        binding.memoEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                viewModel.memo.postValue(p0.toString())
            }
        })
    }
}

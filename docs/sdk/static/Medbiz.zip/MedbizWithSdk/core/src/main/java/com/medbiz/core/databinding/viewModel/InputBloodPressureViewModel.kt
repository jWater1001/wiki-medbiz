package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.Application
import android.util.Log
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.repository.BloodPressureRepository
import com.medbiz.core.databinding.recyclerview.adapter.HorizontalPickerAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.*

class InputBloodPressureViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = InputBloodPressureViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val repository = BloodPressureRepository(application)
    var pillUsageInfo = arrayOf("사용 안 함", "복용함", "복용 안 함")
    var pickeredSystolic = MutableLiveData<Int>()
    var pickeredDiastolic = MutableLiveData<Int>()
    var memo = MutableLiveData<String>()
    var pillUsage = MutableLiveData<String>()
    var pulse = MutableLiveData<Int>()
    val systolicAdapter = HorizontalPickerAdapter()
    val diastolicAdapter = HorizontalPickerAdapter()
    var localeTime = MutableLiveData<String>()
    private var localeTimeDetail = Date().time

    init {
        localeTime.postValue(SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분", Locale.getDefault()).format(Date()))
        pickeredSystolic.postValue(120)
        systolicAdapter.setItemList((75..305).toList())
        systolicAdapter.setMax(301)
        diastolicAdapter.setItemList((-5..125).toList())
        diastolicAdapter.setMax(121)
    }

    fun onClickSavedButton(view: View) {
        var sdf = SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분");
        var timestamp = sdf.parse(localeTime.value).time
        Log.d(tag, "\r\n")
        Log.d(tag, "localeTime  : ${localeTime.value}")
        Log.d(tag, "Systolic    : ${pickeredSystolic.value}")
        Log.d(tag, "Diastolic   : ${pickeredDiastolic.value}")
        Log.d(tag, "pulse       : ${pulse.value}")
        Log.d(tag, "pillUsage   : ${pillUsage.value}")
        Log.d(tag, "memo        : ${memo.value}")
        var data = BloodPressureEntity(
                diastolic = pickeredDiastolic.value!!,
                systolic = pickeredSystolic.value!!,
                pulse = pulse.value,
                map = null,
                timeStamp = localeTimeDetail,
                pill = pillUsage.value,
                memo = memo.value
        )
        scope.launch {
            repository.insert(data)
        }
        (view.context as Activity).onBackPressed()
    }

    fun onClickCanceledButton(view: View) {
        (view.context as Activity).onBackPressed()
    }
}
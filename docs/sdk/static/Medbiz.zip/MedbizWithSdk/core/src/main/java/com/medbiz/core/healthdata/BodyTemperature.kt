package com.medbiz.core.healthdata

class BodyTemperature: HealthConstants() {
    val healthDataType = "com.medbiz.core.healthdata.bodyTemperature"
    var bodyTemperature:Double = 0.0

    init {
        super.dataType = BODY_TEMPERATURE
    }

}

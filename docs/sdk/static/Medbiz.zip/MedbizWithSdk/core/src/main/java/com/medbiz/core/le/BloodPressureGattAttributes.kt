package com.medbiz.core.le

import java.util.*

object BloodPressureGattAttributes {
    private val attributes = hashMapOf<String, String>()

    const val SCAN_PERIOD = 3600000L
    const val STATE_DISCONNECTED = 0
    const val STATE_CONNECTING = 1
    const val STATE_CONNECTED = 2

    val BLOOD_PRESSURE_SERVICE_UUID= convertUUID("00001810-0000-1000-8000-00805f9b34fb")
    val BLOOD_PRESSURE_MEASUREMENT_CHAR_UUID = convertUUID("00002a35-0000-1000-8000-00805f9b34fb")
    val BLOOD_PRESSURE_MEASUREMENT_CCCD_UUID = convertUUID("00002902-0000-1000-8000-00805f9b34fb")
    val DEVICE_INFORMATION_SERVICE_UUID = convertUUID("0000180a-0000-1000-8000-00805f9b34fb")
    val MANUFACTURER_NAME_CHAR_UUID = convertUUID("00002a29-0000-1000-8000-00805f9b34fb")
    val SERIAL_NUMBER_STRING_CHAR_UUID = convertUUID("00002A25-0000-1000-8000-00805f9b34fb")
    val MODEL_NAME_STRING_CHAR_UUID = convertUUID("00002A24-0000-1000-8000-00805f9b34fb")


    const val EXTRA_SYSTOLIC = "com.medbiz.core.le.EXTRA_SYSTOLIC"
    const val EXTRA_DIASTOLIC = "com.medbiz.core.le.EXTRA_DIASTOLIC"
    const val EXTRA_MAP = "com.medbiz.core.le.EXTRA_MAP"
    const val EXTRA_PULSE = "com.medbiz.core.le.EXTRA_PULSE"
    const val ACTION_GATT_CONNECTED = "com.medbiz.core.le.ACTION_GATT_CONNECTED"
    const val ACTION_GATT_DISCONNECTED = "com.medbiz.core.le.ACTION_GATT_DISCONNECTED"
    const val ACTION_GATT_SERVICES_DISCOVERED = "com.medbiz.core.le.ACTION_GATT_SERVICES_DISCOVERED"
    const val ACTION_DATA_AVAILABLE = "com.medbiz.core.le.ACTION_DATA_AVAILABLE"
    const val EXTRA_DATA = "com.medbiz.core.le.EXTRA_DATA"
    const val EXTRA_SERIAL_NUMBER = "com.medbiz.core.le.EXTRA_SERIAL_NUMBER"
    const val EXTRA_DATA_DEVICE_ADDRESS = "com.medbiz.core.le.EXTRA_DATA_DEVICE_ADDRESS"
    const val EXTRA_DATA_DEVICE_NAME = "com.medbiz.core.le.EXTRA_DATA_DEVICE_NAME"
    const val ACTION_FIND_DEVICE = "com.medbiz.core.le.ACTION_FIND_DEVICE"

    private fun convertUUID(uuid: String) = UUID.fromString(uuid)
}
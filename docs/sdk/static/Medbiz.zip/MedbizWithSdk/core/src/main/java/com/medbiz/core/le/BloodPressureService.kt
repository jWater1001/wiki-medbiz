package com.medbiz.core.le

import android.app.Service
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.util.Log
import java.util.*
import kotlin.collections.HashSet


class BloodPressureService : Service() {
    private val tag = BloodPressureService::class.java.name
    private val filterDeviceName = listOf("A&D", "HEM", "BLEsmart")
    var isState = false
    private var bloodPressureServiceState = false
    private var mHandler: Handler? = null
    private var mBluetoothManager: BluetoothManager? = null
    private var mBluetoothAdapter: BluetoothAdapter? = null
    private var mBluetoothGatt: BluetoothGatt? = null
    private var mBluetoothDevice: BluetoothDevice? = null
    private var mDescriptor: BluetoothGattDescriptor? = null
    private var mBLEScanner: BluetoothLeScanner? = null
    private var mScanning = false
    private val scannedDevices: MutableSet<BluetoothDevice> = HashSet()
    private var bondedDevices: Set<BluetoothDevice> = HashSet()
    private val mBluetoothDeviceAddress: String? = null
    private var mConnectionState = BloodPressureGattAttributes.STATE_DISCONNECTED

    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change, services discovered and data transfer/receive
    private val mGattCallback: BluetoothGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val intentAction: String
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(tag, "Connected to GATT server.")
                intentAction = BloodPressureGattAttributes.ACTION_GATT_CONNECTED
                mConnectionState = BloodPressureGattAttributes.STATE_CONNECTED
                broadcastUpdate(intentAction)

                // Attempts to discover services after successful connection.
                Log.i(tag, "Attempting to start service discovery:" + mBluetoothGatt!!.discoverServices())
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i(tag, "Disconnected from GATT server.")
                intentAction = BloodPressureGattAttributes.ACTION_GATT_DISCONNECTED
                mConnectionState = BloodPressureGattAttributes.STATE_DISCONNECTED
                broadcastUpdate(intentAction)
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(tag, "onServicesDiscovered : $status")
                broadcastUpdate(BloodPressureGattAttributes.ACTION_GATT_SERVICES_DISCOVERED)
            } else {
                Log.i(tag, "onServicesDiscovered: $status")
            }
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt,
                                          characteristic: BluetoothGattCharacteristic,
                                          status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(BloodPressureGattAttributes.ACTION_DATA_AVAILABLE, characteristic)
            }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt,
                                           characteristic: BluetoothGattCharacteristic,
                                           status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(BloodPressureGattAttributes.ACTION_DATA_AVAILABLE, characteristic)
            }
        }



        override fun onCharacteristicChanged(gatt: BluetoothGatt,
                                             characteristic: BluetoothGattCharacteristic) {
            broadcastUpdate(BloodPressureGattAttributes.ACTION_DATA_AVAILABLE, characteristic)
        }
    }

    private fun broadcastUpdate(action: String, deviceName: String, deviceAddress: String) {
        val intent = Intent(action)
        intent.putExtra(BloodPressureGattAttributes.EXTRA_DATA_DEVICE_NAME, deviceName)
        intent.putExtra(BloodPressureGattAttributes.EXTRA_DATA_DEVICE_ADDRESS, deviceAddress)
        sendBroadcast(intent)
    }

    private fun broadcastUpdate(action: String) {
        val intent = Intent(action)
        sendBroadcast(intent)
    }

    fun byteArrayToHexString(bytes: ByteArray): String {
        val sb = java.lang.StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02X, ", b))
        }
        return sb.toString()
    }

    private fun broadcastUpdate(action: String,
                                characteristic: BluetoothGattCharacteristic) {
        val intent = Intent(action)
        // This is special handling for the Heart Rate Measurement profile.  Data parsing is
        // carried out as per profile specifications:
        // http://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.heart_rate_measurement.xml
        if (BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CHAR_UUID == characteristic.uuid) {
            Log.i(tag, "UUID_BLOOD_PRESSURE_MEASUREMENT Broadcast!!!!")
            val flag = characteristic.properties
            Log.i(tag, "flag = $flag")
            val data = characteristic.value
            Log.i(tag, "data = ${byteArrayToHexString(data)}")
            var format = -1
            if (flag and 0x01 != 0) {
                format = BluetoothGattCharacteristic.FORMAT_UINT16
                Log.i(tag, "Heart rate format UINT16.")
            } else {
                format = BluetoothGattCharacteristic.FORMAT_UINT8
                Log.i(tag, "Heart rate format UINT8.")
            }
            var unit = characteristic.getIntValue(format, 0)
            var unitString = ""
            if(unit == 0) unitString = "kPa"
            else unitString = "mmHg"
            var systolic = characteristic.getIntValue(format, 1)
            Log.i(tag, String.format("Received systolic: %d", systolic))
            var diastolic = characteristic.getIntValue(format, 3)
            Log.i(tag, String.format("Received diastolic: %d", diastolic))
            var map = characteristic.getIntValue(format, 5)
            Log.i(tag, String.format("Received map: %d", map))
            var pulse = 0
            var isTime = flag and 0x02
            Log.i(tag, "isTime data : $isTime")
            if (isTime != 0) {
                format = BluetoothGattCharacteristic.FORMAT_UINT16
                Log.i(tag, "Heart rate format UINT16.")
                pulse = characteristic.getIntValue(format, 14)
                Log.i(tag, String.format("Received pulse: %d", pulse))
            } else {
                pulse = characteristic.getIntValue(format, 7)
                Log.i(tag, String.format("Received pulse: %d", pulse))
            }
            intent.putExtra(BloodPressureGattAttributes.EXTRA_SYSTOLIC, systolic)
            intent.putExtra(BloodPressureGattAttributes.EXTRA_DIASTOLIC, diastolic)
            intent.putExtra(BloodPressureGattAttributes.EXTRA_MAP, map)
            intent.putExtra(BloodPressureGattAttributes.EXTRA_PULSE, pulse)
        } else if (BloodPressureGattAttributes.SERIAL_NUMBER_STRING_CHAR_UUID == characteristic.uuid) {
            Log.i(tag, "UUID_DEVICE_SERIAL Broadcast!!!!")
            val serialNumber = characteristic.getStringValue(0)
            Log.i(tag, "Serial Number is $serialNumber")
            intent.putExtra(BloodPressureGattAttributes.EXTRA_SERIAL_NUMBER, serialNumber)
        } else {
            // For all other profiles, writes the data formatted in HEX.
            val data = characteristic.value
            if (data != null) {
                val stringBuilder = StringBuilder(data.size)
                for (byteChar in data)
                    stringBuilder.append(String.format("%02X ", byteChar))
                intent.putExtra(BloodPressureGattAttributes.EXTRA_DATA, "${String(data)} " + "\n" + "$stringBuilder")
            }
        }
        sendBroadcast(intent)
    }

    inner class LocalBinder : Binder() {
        val service: BloodPressureService
            get() = this@BloodPressureService
    }

    override fun onBind(intent: Intent): IBinder? {
        if (initialize()) {
            Log.i(tag, "onBind() initialize Success")
        } else {
            Log.i(tag, "onbind() initialize Fail")
        }
        mHandler = Handler()
        bondedDevices = mBluetoothAdapter!!.bondedDevices
        for (device in bondedDevices) {
            scannedDevices.add(device)
        }
        scanLeDevice(true)
        return mBinder
    }

    override fun onUnbind(intent: Intent): Boolean {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        Log.i(tag, "onUnbind : disconnect(), close() Call")
        scanLeDevice(false)
        close()
//        mBluetoothGatt = null
        return super.onUnbind(intent)
    }

    private val mBinder: IBinder = LocalBinder()

    override fun onDestroy() {
        Log.i(tag, "onDestory()")
        super.onDestroy()
    }

    private fun initialize(): Boolean {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            if (mBluetoothManager == null) {
                Log.e(tag, "Unable to initialize BluetoothManager.")
                return false
            }
        }

        mBluetoothAdapter = mBluetoothManager!!.adapter
        if (mBluetoothAdapter == null && mBluetoothAdapter!!.isEnabled) {
            Log.e(tag, "Unable to obtain a BluetoothAdapter.")
            return false
        }

        mBLEScanner = mBluetoothAdapter?.bluetoothLeScanner
        if (mBLEScanner == null) {
            Log.e(tag, "Unable to obtain a LeScanner.")
            return false
        }
        Log.i(tag, "Set mBluetoothManager, enable to obtain a BluetoothAdapter.")
        if (mBluetoothManager != null && mBluetoothAdapter != null && mBLEScanner != null) {
            Log.i(tag, mBluetoothManager.toString() + ", " + mBluetoothAdapter.toString() + ", " + mBLEScanner.toString())
        }
        return true
    }

    fun connect(address: String?): Boolean {
        if (address == null) {
            Log.i(tag, "BluetoothAdapter not initialized or unspecified address.")
            return false
        }
        if (!bloodPressureServiceState) {
            mBluetoothDevice = mBluetoothAdapter!!.getRemoteDevice(address)
            if (mBluetoothDevice == null) {
                Log.i(tag, "Device not found.  Unable to connect.")
                return false
            }
        }

        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        if (!bloodPressureServiceState) {
            mBluetoothGatt = mBluetoothDevice!!.connectGatt(this, true, mGattCallback)
            bloodPressureServiceState = true
            Log.i(tag, "connected address  : $address")
        }
        mBluetoothGatt!!.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_LOW_POWER)
        mConnectionState = BloodPressureGattAttributes.STATE_CONNECTING
        return true
    }

    fun disconnect() {
        Log.i(tag, "disconnect() call")
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.i(tag, "disconnect() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }

        mBluetoothGatt!!.disconnect()
    }

    fun close() {
        if (mBluetoothGatt == null) {
            Log.i(tag, "close() : mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.close()
    }

    fun readCharacteristic(characteristic: BluetoothGattCharacteristic?) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.i(tag, "readCharacteristic() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.readCharacteristic(characteristic)
    }

    fun setCharacteristicNotification(characteristic: BluetoothGattCharacteristic,
                                      enabled: Boolean) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.i(tag, "setCharacteristicNotification() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)
        // This is specific to Heart Rate Measurement.
        if (BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CHAR_UUID == characteristic.uuid) {
            val descriptor = characteristic.getDescriptor(BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CCCD_UUID)
            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            mBluetoothGatt!!.writeDescriptor(descriptor)
        }
    }

    fun setCharacteristicIndication(characteristic: BluetoothGattCharacteristic,
                                    enabled: Boolean) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.i(tag, "setCharacteristicIndication() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        var res = mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)
        if (res) {
            if (BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CHAR_UUID == characteristic.uuid) {
                Log.i(tag, "Indication Write Start")
                val descriptor = characteristic.getDescriptor(
                        BloodPressureGattAttributes.BLOOD_PRESSURE_MEASUREMENT_CCCD_UUID)
                Log.i(tag, "descriptor UUID  is : " + descriptor.uuid.toString())
                mDescriptor = descriptor
                val isIndication = byteArrayOf(0x02, 0x00)
                res = descriptor.setValue(isIndication)
                if (res) {
                    mHandler!!.postDelayed({
                        Log.i(tag, "descriptor.setValue() return True")
                        val res = mBluetoothGatt!!.writeDescriptor(mDescriptor)
                        Log.i(tag, "mBluetoothGatt.writeDescriptor() res 1 is : $res")
                    }, 1000)
                }
            }
        }
    }

    val supportedGattServices: List<BluetoothGattService>?
        get() {
            if (mBluetoothGatt == null) return null
            val services = mBluetoothGatt!!.services
            Log.i(tag, "services len is " + services.size)
            return services
        }

    fun getGattService(uuid: UUID?): BluetoothGattService? {
        return if (mBluetoothGatt == null) null else mBluetoothGatt!!.getService(uuid)
    }

    private fun scanLeDevice(enable: Boolean) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler!!.postDelayed({
                mScanning = false
                if (mBLEScanner != null) {
                    Log.i(tag, "LeScanStop()")
                    mBLEScanner!!.stopScan(mScanCallback)
                } else {
                    Log.e(tag, "Unable to obtain a LeScanner.")
                }
            }, BloodPressureGattAttributes.SCAN_PERIOD)
            mScanning = true
            if (mBLEScanner != null) {
                Log.i(tag, "LeScanStart()")
                mBLEScanner!!.startScan(mScanCallback)
            } else {
                Log.e(tag, "Unable to obtain a LeScanner.")
            }
        } else {
            mScanning = false
            if (mBLEScanner != null) {
                Log.i(tag, "LeScanStop() 22")
                mBLEScanner!!.stopScan(mScanCallback)
            } else {
                Log.e(tag, "Unable to obtain a LeScanner.")
            }
        }
    }

    private val mScanCallback: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            processResult(result)
        }

        override fun onBatchScanResults(results: List<ScanResult>) {
            for (result in results) {
                processResult(result)
            }
        }
        override fun onScanFailed(errorCode: Int) {}

        private fun processResult(result: ScanResult) {
            val device = result.device
            scannedDevices.add(device)
            if (device.name != null) {
                for (filterDeviceName in filterDeviceName) {
                    if (device.name.contains(filterDeviceName)) {
//                        scanLeDevice(false);
                        Log.i(tag, "Device is scanned !!")
                        val intentAction = BloodPressureGattAttributes.ACTION_FIND_DEVICE
                        broadcastUpdate(intentAction, device.name, device.address)
                    }
                }
            }
        }
    }

    fun getmBLEScanner(): BluetoothLeScanner? {
        return mBLEScanner
    }

    fun setmBLEScanner(mBLEScanner: BluetoothLeScanner?) {
        this.mBLEScanner = mBLEScanner
    }
}
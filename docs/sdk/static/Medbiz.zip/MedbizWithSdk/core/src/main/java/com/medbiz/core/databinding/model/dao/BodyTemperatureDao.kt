package com.medbiz.core.databinding.model.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.entity.BodyTemperatureEntity

@Dao
interface BodyTemperatureDao {
    @Query("SELECT * FROM body_temperature")
    suspend fun getAll(): List<BodyTemperatureEntity>

    @Query("SELECT COUNT(id) FROM body_temperature")
    suspend fun getSize(): Int

    @Query("SELECT * FROM body_temperature ORDER BY timeStamp DESC limit 1")
    fun getLatestMeasuredData(): LiveData<BodyTemperatureEntity>

    @Query("DELETE FROM body_temperature")
    suspend fun deleteAll()

    @Insert
    suspend fun insert(vararg glucoseEntity: BodyTemperatureEntity)
    
    @Delete
    suspend fun delete(vararg glucoseEntity: BodyTemperatureEntity)

    @Update
    suspend fun update(vararg glucoseEntity: BodyTemperatureEntity)
}
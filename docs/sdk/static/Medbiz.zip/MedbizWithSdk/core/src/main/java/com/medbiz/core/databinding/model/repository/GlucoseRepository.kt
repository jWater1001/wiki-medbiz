package com.medbiz.core.databinding.model.repository

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.room.Query
import com.medbiz.core.databinding.model.database.AppDB
import com.medbiz.core.databinding.model.entity.GlucoseEntity

class GlucoseRepository(application: Application) {
    private var glucoseDao = AppDB.getInstance(application)!!.glucoseDao()

    fun getDBInstance(): AppDB.Companion {
        return AppDB
    }

    suspend fun getAll(): List<GlucoseEntity> {
        return glucoseDao.getAll()
    }

    suspend fun getSize(): Int {
        return glucoseDao.getSize()
    }

    suspend fun getLatestMeasuredDataSequence(): Long {
        return glucoseDao.getLatestMeasuredDataSequence()
    }

    fun getLatestMeasuredData(): LiveData<GlucoseEntity> {
        return glucoseDao.getLatestMeasuredData()
    }

    fun getContextMealBySequence(): LiveData<GlucoseEntity> {
        return glucoseDao.getContextMealBySequence()
    }

    suspend fun getDataBySequence(sequence: Long): GlucoseEntity? {
        return glucoseDao.getDataBySequence(sequence)
    }

    suspend fun insert(GlucoseEntity: GlucoseEntity) {
        glucoseDao.insert(GlucoseEntity)
    }

    suspend fun deleteAll() {
        glucoseDao.deleteAll()
    }

    suspend fun delete(glucoseEntity: GlucoseEntity) {
        glucoseDao.delete(glucoseEntity)
    }

    suspend fun update(glucoseEntity: GlucoseEntity) {
        glucoseDao.update(glucoseEntity)
    }

    suspend fun updateContextMeal(glucoseEntity: GlucoseEntity) {
        glucoseDao.updateContextMeal(glucoseEntity.id as Int, glucoseEntity.contextMeal)
    }
    suspend fun updateGlucose(glucoseEntity: GlucoseEntity) {
        glucoseDao.updateGlucose(glucoseEntity.id as Int, glucoseEntity.glucose, glucoseEntity.timeStamp)
    }

}

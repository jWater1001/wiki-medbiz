package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.util.Log

import android.view.View
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.medbiz.core.databinding.view.MainActivity
import com.medbiz.core.singleton.Preferences
import com.medbiz.sdk.openapi.Password
import com.medbiz.sdk.openapi.UserMe
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = LoginViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val oAuthTokenRepository = OAuthTokenRepository(application)
    private val userMeRepository = UserMeRepository(application)
    lateinit var token: LiveData<OAuthTokenEntity>
    var usernameLiveData = MutableLiveData<String>()
    var passwordLiveData = MutableLiveData<String>()
    fun onLoginButtonClick(view: View, username: String, password: String) {
        scope.launch {
            Preferences.savedId = username
            Preferences.savedPwd = password
            val res = Password(oAuthTokenRepository).requestAccessToken(username, password)
            if(res != null) {
                Toast.makeText(getApplication(), "Login Success", Toast.LENGTH_LONG).show()
                UserMe(userMeRepository).getUserMe("Bearer " + res.accessToken)
                var intent = Intent(view.context, MainActivity::class.java)
                (view.context as Activity).startActivity(intent)
                (view.context as Activity).finish()
            } else {
                MaterialAlertDialogBuilder(view.context)
                        .setMessage("medbiz 계정또는 비밀번호를 다시확인해주세요.")
                        .setPositiveButton("확인") { _, _ ->
                            passwordLiveData.postValue("")
                            usernameLiveData.postValue("")
                        }.show()
            }
        }
    }

    fun onSignUpButtonClick(view: View) {
        Toast.makeText(getApplication(), "onSignUpButtonClick", Toast.LENGTH_LONG).show()
        // api 호출
//        (view.context as Activity).finish()
    }
}
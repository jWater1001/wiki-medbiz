 package com.medbiz.core.le

import android.app.Service
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.util.Log
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import kotlin.experimental.and
import kotlin.math.pow
import kotlin.math.roundToInt

class GlucoseService : Service() {
    private val tag = GlucoseService::class.java.name
    private val filterDeviceName = listOf("CareSens")
    
    var isState = false
    private var mHandler: Handler? = null
    private var mScanning = false
    private var mBluetoothManager: BluetoothManager? = null
    private var mBluetoothAdapter: BluetoothAdapter? = null
    private var mBluetoothGatt: BluetoothGatt? = null
    private var mDescriptor: BluetoothGattDescriptor? = null
    private var mBLEScanner: BluetoothLeScanner? = null
    private val scannedDevices: MutableSet<BluetoothDevice> = HashSet()
    private var bondedDevices: Set<BluetoothDevice> = HashSet()
    private var mBluetoothDeviceAddress: String? = null
    private var mConnectionState = GlucoseGattAttributes.STATE_DISCONNECTED

    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private val mGattCallback: BluetoothGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val intentAction: String
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                //Log.d(tag, "Connected to GATT server.")
                intentAction = GlucoseGattAttributes.ACTION_GATT_CONNECTED
                mConnectionState = GlucoseGattAttributes.STATE_CONNECTED
                broadcastUpdate(intentAction)

                // Attempts to discover services after successful connection.
                Log.i(tag, "Attempting to start service discovery:" + mBluetoothGatt!!.discoverServices())
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                //Log.d(tag, "Disconnected from GATT server.")
                intentAction = GlucoseGattAttributes.ACTION_GATT_DISCONNECTED
                mConnectionState = GlucoseGattAttributes.STATE_DISCONNECTED
                broadcastUpdate(intentAction)
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                //Log.d(tag, "onServicesDiscovered : $status")
                broadcastUpdate(GlucoseGattAttributes.ACTION_GATT_SERVICES_DISCOVERED)
            } else {
                //Log.d(tag, "onServicesDiscovered received: $status")
            }
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt,
                                          characteristic: BluetoothGattCharacteristic,
                                          status: Int) {
            //Log.d(tag, "onCharacteristicRead : " + characteristic.uuid.toString() + " status : " + status)
            if (status == BluetoothGatt.GATT_SUCCESS) {

            }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt,
                                           characteristic: BluetoothGattCharacteristic,
                                           status: Int) {
            //Log.d(tag, "[onCharacteristicWrite] : " + characteristic.uuid.toString() + " status : " + status)
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (characteristic.uuid == GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CHAR_UUID) {
                    //Log.d(tag, "[RECORD_ACCESS_CONTROL_POINT_CHAR_UUID] write Success !! ")
                }
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt,
                                             characteristic: BluetoothGattCharacteristic) {
            //Log.d(tag, "[onCharacteristicChanged] res : " + characteristic.uuid.toString())
            if (characteristic.uuid == GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CHAR_UUID) {
                broadcastUpdate(GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_MEASUREMENT_CHAR, characteristic)
            } else if (characteristic.uuid == GlucoseGattAttributes.GLUCOSE_CONTEXT_CHAR_UUID) {
                broadcastUpdate(GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_CONTEXT_CHAR, characteristic)
            } else if (characteristic.uuid == GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CCCD_UUID) {
                broadcastUpdate(GlucoseGattAttributes.ACTION_CHANGED_RECORD_ACCESS_CONTROL_POINT_CHAR, characteristic)
            }
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            //Log.d(tag, "[onDescriptor's CHAR] res : " + descriptor.characteristic.uuid.toString() + " status : " + status)
            //Log.d(tag, "[onDescriptorWrite] res : " + descriptor.uuid.toString() + " status : " + status)
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (descriptor.characteristic.uuid == GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CHAR_UUID) {
                    //Log.d(tag, "[GLUCOSE_MEASUREMENT_CCCD] Notification Enabled!")
                    broadcastUpdate(GlucoseGattAttributes.ACTION_ENABLE_GLUCOSE_CONTEXT_NOTIFICATION, descriptor)
                } else if (descriptor.characteristic.uuid == GlucoseGattAttributes.GLUCOSE_CONTEXT_CHAR_UUID) {
                    //Log.d(tag, "[GLUCOSE_CONTEXT_CCCD] Notification Enabled!")
                    broadcastUpdate(GlucoseGattAttributes.ACTION_ENABLE_RECORD_ACCESS_CONTROL_POINT_INDICATION, descriptor)
                } else if (descriptor.characteristic.uuid == GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CHAR_UUID) {
                    //Log.d(tag, "[RECORD_ACCESS_CONTROL_POINT_CCCD] Indication Enabled!")
                    broadcastUpdate(GlucoseGattAttributes.ACTION_WRITE_RECORD_ACCESS_CONTROL_POINT_CHAR, descriptor)
                }
            }
        }
    }

    fun getUnsignedIntFrom(data: ByteArray, offset: Int): Int {
        return (data[offset].toUByte() and 0xff.toUByte()).toInt()
    }
    
    private fun broadcastUpdate(action: String, deviceName: String, deviceAddress: String) {
        val intent = Intent(action)
        intent.putExtra(GlucoseGattAttributes.EXTRA_DATA_DEVICE_NAME, deviceName)
        intent.putExtra(GlucoseGattAttributes.EXTRA_DATA_DEVICE_ADDRESS, deviceAddress)
        sendBroadcast(intent)
    }

    private fun broadcastUpdate(action: String) {
        val intent = Intent(action)
        sendBroadcast(intent)
    }
    
    private fun broadcastUpdate(action: String,
                                characteristic: BluetoothGattCharacteristic) {
        val intent = Intent(action)
        if (GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CHAR_UUID == characteristic.uuid) {
            //Log.d(tag, "[UUID_GLUCOSE_MEASUREMENT] Broadcast !!!!")
            val data = characteristic.value
            val flagTimeOffsetPresent: Boolean
            val flagGlucoseConcentrationTypeAndSampleLoation: Boolean
            val flagGlucoseConcentrationUnits: Boolean
            val flagSensorStatusAnnunciationPresent: Boolean
            val flatContextInformationFollows: Boolean
            val sequence: Long
            val year: Int
            val month: Int
            val day: Int
            val hour: Int
            val minute: Int
            val second: Int
            val timeOffset: Int
            val mantissa: Int
            var exponent: Int
            val glucose: Int
            val buffer = ByteBuffer.wrap(data)
            if (data != null && data.isNotEmpty()) {
                val flag = getUnsignedIntFrom(data, 0)
                flagTimeOffsetPresent = flag shr 0 and 0x01 == 0x01
                flagGlucoseConcentrationTypeAndSampleLoation = flag shr 1 and 0x01 == 0x01
                flagGlucoseConcentrationUnits = flag shr 2 and 0x01 == 0x01
                flagSensorStatusAnnunciationPresent = flag shr 3 and 0x01 == 0x01
                flatContextInformationFollows = flag shr 4 and 0x01 == 0x01
//                Log.d(tag, "[Flag]"
//                        + "\tflagTimeOffsetPresent : " + flagTimeOffsetPresent
//                        + "\tflagGlucoseConcentrationTypeAndSampleLoation : " + flagGlucoseConcentrationTypeAndSampleLoation
//                        + "\tflagGlucoseConcentrationUnits : " + flagGlucoseConcentrationUnits
//                        + "\tflagSensorStatusAnnunciationPresent : " + flagSensorStatusAnnunciationPresent
//                        + "\tflatContextInformationFollows : " + flatContextInformationFollows)
                sequence = (getUnsignedIntFrom(data, 2) * 256 + getUnsignedIntFrom(data, 1)).toLong()
                intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT_SEQUENCE, sequence)
                //Log.d(tag, "[EXTRA_GLUCOSE_MEASUREMENT_SEQUENCE] : $sequence")
                year = getUnsignedIntFrom(data, 4) * 256 + getUnsignedIntFrom(data, 3)
                month = getUnsignedIntFrom(data, 5)
                day = getUnsignedIntFrom(data, 6)
                hour = getUnsignedIntFrom(data, 7)
                minute = getUnsignedIntFrom(data, 8)
                second = getUnsignedIntFrom(data, 9)
                val calendar = Calendar.getInstance()
                calendar[year, month - 1, day, hour, minute] = second
                val measuredTime = calendar.timeInMillis
                intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT_TIME, measuredTime)
                //Log.d(tag, "[EXTRA_GLUCOSE_MEASUREMENT_TIME] date : $measuredTime")
                timeOffset = getUnsignedIntFrom(data, 11) * 256 + getUnsignedIntFrom(data, 10)
                val rawGlucose = getUnsignedIntFrom(data, 13) * 256 + getUnsignedIntFrom(data, 12)
                //Log.d(tag, "[rawGlucose] value : $rawGlucose")
                exponent = rawGlucose shr 12
                if (exponent >= 0x08) {
                    exponent = (15 - exponent + 1) * -1
                }
                mantissa = (rawGlucose and 0x0f00) + rawGlucose and 0x00ff
                if (!flagGlucoseConcentrationUnits) {
                    // units is Kg/L in Standard, but measurement units in is mg/dL;
                    // 1dL == 100mL
                    // 168 * 10^-5 kg/L ==> 168 * 10^-5 * 10^6 / 10 mg/dL
                    val test = (mantissa * 10.0.pow(exponent.toDouble()) * 10.0.pow(6.0) / 10.0).roundToInt().toFloat()
                    glucose = (mantissa * 10.0.pow(exponent.toDouble()) * 10.0.pow(6.0) / 10.0).roundToInt()
                    //Log.d(tag, "[EXTRA_GLUCOSE_MEASUREMENT] : $glucose, $test")
                    intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT, glucose)
                }
                val glucoseType = getUnsignedIntFrom(data, 14) shr 4
                if (glucoseType == 1) {
                    //Log.d(tag, "[EXTRA_GLUCOSE_BLOOD_TYPE] : Capillary Whole blood")
                    intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_BLOOD_TYPE, GlucoseGattAttributes.GLUCOSE_BLOOD_TYPE_CAPILLARY_WHOLE_BLOOD)
                }
                val glucoseSampleLocation = getUnsignedIntFrom(data, 14) and 0x0f
                if (glucoseSampleLocation == 1) {
                    //Log.d(tag, "[EXTRA_GLUCOSE_SAMPLE_LOCATION] : Finger")
                    intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_SAMPLE_LOCATION, GlucoseGattAttributes.GLUCOSE_SAMPLE_LOCATION_FINGER)
                }
            }
        } else if (GlucoseGattAttributes.GLUCOSE_CONTEXT_CHAR_UUID == characteristic.uuid) {
            //Log.d(tag, "[UUID_GLUCOSE_CONTEXT] Broadcast !!!!")
            val data = characteristic.value
            if (data != null && data.isNotEmpty()) {
                val flag = getUnsignedIntFrom(data, 0)
                val sequence = (getUnsignedIntFrom(data, 2) * 256 + getUnsignedIntFrom(data, 1)).toLong()
                intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_SEQUENCE, sequence)
                //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_SEQUENCE] : $sequence")
                if (flag and 0x02 == 0x02) {
                    val mealPresent = getUnsignedIntFrom(data, 3)
                    if (mealPresent == 0) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_RESERVED_FOR_FUTURE_USE)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_RESERVED_FOR_FUTURE_USE")
                    } else if (mealPresent == 1) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_PREPRANDIAL)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_PREPRANDIAL")
                    } else if (mealPresent == 2) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_POSTPRANDIAL)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_POSTPRANDIAL")
                    } else if (mealPresent == 3) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_FASTING)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_FASTING")
                    } else if (mealPresent == 4) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_CASUAL)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_CASUAL")
                    } else if (mealPresent == 5) {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_BEDTIME)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_BEDTIME")
                    } else {
                        intent.putExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT, GlucoseGattAttributes.GLUCOSE_MEAL_NONE)
                        //Log.d(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : there is no contextMeal data")
                    }
                }
            }
        } else if (GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CHAR_UUID == characteristic.uuid) {
            //Log.d(tag, "[UUID_RECORD_ACCESS_CONTROL_POINT] Broadcast !!!!")
        } else if (GlucoseGattAttributes.SERIAL_NUMBER_STRING_CHAR_UUID == characteristic.uuid) {
            //Log.d(tag, "UUID_DEVICE_SERIAL Broadcast!!!!")
            val serialNumber = characteristic.getStringValue(0)
            //Log.d(tag, "Serial Number is $serialNumber")
        } else {
            // For all other profiles, writes the data formatted in HEX.
            val data = characteristic.value
            if (data != null && data.isNotEmpty()) {
                val stringBuilder = StringBuilder(data.size)
                for (byteChar in data) stringBuilder.append(String.format("%02X ", byteChar))
            }
        }
        sendBroadcast(intent)
    }

    private fun broadcastUpdate(action: String,
                                descriptor: BluetoothGattDescriptor) {
        //Log.d(tag, "[broadcastUpdate] Descriptor :$action")
        val intent = Intent(action)
        if (GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CCCD_UUID == descriptor.uuid) {

        } else if (GlucoseGattAttributes.GLUCOSE_CONTEXT_CCCD_UUID == descriptor.uuid) {

        } else if (GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CCCD_UUID == descriptor.uuid) {

        }
        sendBroadcast(intent)
    }

    inner class LocalBinder : Binder() {
        val service: GlucoseService
            get() = this@GlucoseService
    }

    override fun onBind(intent: Intent): IBinder? {
        if (initialize()) {
            //Log.d(tag, "initialize Success")
        } else {
            //Log.d(tag, "initialize Fail")
        }
        mHandler = Handler()
        bondedDevices = mBluetoothAdapter!!.bondedDevices
        for (device in bondedDevices) {
            scannedDevices.add(device)
        }
        scanLeDevice(true)
        return mBinder
    }

    override fun onUnbind(intent: Intent): Boolean {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        //Log.d(tag, "onUnbind : disconnect(), close() Call")
        scanLeDevice(false)
        close()
        mBluetoothGatt = null
        return super.onUnbind(intent)
    }

    private val mBinder: IBinder = LocalBinder()

    override fun onDestroy() {
        //Log.d(tag, "onDestory()")
        super.onDestroy()
    }

    fun initialize(): Boolean {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            if (mBluetoothManager == null) {
                Log.e(tag, "Unable to initialize BluetoothManager.")
                return false
            }
        }
        mBluetoothAdapter = mBluetoothManager!!.adapter
        if (mBluetoothAdapter == null && mBluetoothAdapter!!.isEnabled) {
            Log.e(tag, "Unable to obtain a BluetoothAdapter.")
            return false
        }
        mBLEScanner = mBluetoothAdapter!!.bluetoothLeScanner
        if (mBLEScanner == null) {
            Log.e(tag, "Unable to obtain a LeScanner.")
            return false
        }
        //Log.d(tag, "Set mBluetoothManager, enable to obtain a BluetoothAdapter.")
        if (mBluetoothManager != null && mBluetoothAdapter != null && mBLEScanner != null) {
            //Log.d(tag, mBluetoothManager.toString() + ", " + mBluetoothAdapter.toString() + ", " + mBLEScanner.toString())
        }
        return true
    }

    fun connect(address: String?): Boolean {
        if (address == null) {
            //Log.d(tag, "BluetoothAdapter not initialized or unspecified address.")
            return false
        }
        val device = mBluetoothAdapter!!.getRemoteDevice(address)
        if (device == null) {
            //Log.d(tag, "Device not found.  Unable to connect.")
            return false
        }

        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        mBluetoothGatt = device.connectGatt(this, true, mGattCallback)
        //Log.d(tag, "Trying to create a new connection.")
        //Log.d(tag, "connected address  : $address")
        mBluetoothDeviceAddress = address

        mBluetoothGatt!!.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
        mConnectionState = GlucoseGattAttributes.STATE_CONNECTING
        return true
    }

    fun disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            //Log.d(tag, "disconnect() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        //Log.d(tag, "disconnect() call")
        mBluetoothGatt!!.disconnect()
    }

    fun close() {
        if (mBluetoothGatt == null) {
            //Log.d(tag, "close() : mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.close()
    }

    fun writeCharacteristic(characteristic: BluetoothGattCharacteristic?) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            //Log.d(tag, "readCharacteristic() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.writeCharacteristic(characteristic)
    }

    fun readCharacteristic(characteristic: BluetoothGattCharacteristic?) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            //Log.d(tag, "readCharacteristic() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.readCharacteristic(characteristic)
    }

    fun setCharacteristicNotification(characteristic: BluetoothGattCharacteristic,
                                      enabled: Boolean) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            //Log.d(tag, "setCharacteristicNotification() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)
        //Log.d(tag, "requested noti char is " + characteristic.uuid)
        if (GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CHAR_UUID == characteristic.uuid) {
            val descriptor = characteristic.getDescriptor(GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CCCD_UUID)
            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            mBluetoothGatt!!.writeDescriptor(descriptor)
        } else if (GlucoseGattAttributes.GLUCOSE_CONTEXT_CHAR_UUID == characteristic.uuid) {
            val descriptor = characteristic.getDescriptor(GlucoseGattAttributes.GLUCOSE_CONTEXT_CCCD_UUID)
            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            mBluetoothGatt!!.writeDescriptor(descriptor)
        }
    }

    /**
     * setting Indication on characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled If true, enable notification.  False otherwise.
     */
    fun setCharacteristicIndication(characteristic: BluetoothGattCharacteristic,
                                    enabled: Boolean) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            //Log.d(tag, "setCharacteristicIndication() : mBluetoothAdapter or mBluetoothGatt not initialized")
            return
        }
        var res = mBluetoothGatt!!.setCharacteristicNotification(characteristic, enabled)
        if (res) {
            if (GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CHAR_UUID == characteristic.uuid) {
                //Log.d(tag, "Indication Write Start")
                val descriptor = characteristic.getDescriptor(GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CCCD_UUID)
                //Log.d(tag, "descriptor UUID  is : " + descriptor.uuid.toString())
                mDescriptor = descriptor
                res = descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE)
                //Log.d(tag, "descriptor.setValue() return : $res")
                res = mBluetoothGatt!!.writeDescriptor(mDescriptor)
                //Log.d(tag, "mBluetoothGatt.writeDescriptor() res 1 is : $res")
            }
        }
    }

    /**
     * Retrieves a list of supported GATT services on the connected device. This should be
     * invoked only after `BluetoothGatt#discoverServices()` completes successfully.
     *
     * @return A `List` of supported services.
     */
    val supportedGattServices: List<BluetoothGattService>?
        get() {
            if (mBluetoothGatt == null) return null
            val services = mBluetoothGatt!!.services
            //Log.d(tag, "services len is " + services.size)
            return services
        }

    fun getGattService(uuid: UUID?): BluetoothGattService? {
        return if (mBluetoothGatt == null) null else mBluetoothGatt!!.getService(uuid)
    }

    private fun scanLeDevice(enable: Boolean) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler!!.postDelayed({
                mScanning = false
                if (mBLEScanner != null) {
                    //Log.d(tag, "LeScanStop()")
                    mBLEScanner!!.stopScan(mScanCallback)
                } else {
                    Log.e(tag, "Unable to obtain a LeScanner.")
                }
            }, GlucoseGattAttributes.SCAN_PERIOD)
            mScanning = true
            if (mBLEScanner != null) {
                //Log.d(tag, "LeScanStart()")
                mBLEScanner!!.startScan(mScanCallback)
            } else {
                Log.e(tag, "Unable to obtain a LeScanner.")
            }
        } else {
            mScanning = false
            if (mBLEScanner != null) {
                //Log.d(tag, "LeScanStop()")
                mBLEScanner!!.stopScan(mScanCallback)
            } else {
                Log.e(tag, "Unable to obtain a LeScanner.")
            }
        }
    }

    private val mScanCallback: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            processResult(result)
        }

        override fun onBatchScanResults(results: List<ScanResult>) {
            for (result in results) {
                processResult(result)
            }
        }

        override fun onScanFailed(errorCode: Int) {}
        private fun processResult(result: ScanResult) {
            val device = result.device
            scannedDevices.add(device)
            if (device.name != null && !device.name.isEmpty()) {
                for (filterDeviceName in filterDeviceName) {
                    if (device.name.contains(filterDeviceName)) {
                        scanLeDevice(false)
                        //Log.d(tag, "Device is scanned !!")
                        val intentAction = GlucoseGattAttributes.ACTION_FIND_DEVICE
                        broadcastUpdate(intentAction, device.name, device.address)
                    }
                }
            }
        }
    }
}
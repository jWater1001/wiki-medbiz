package com.medbiz.core.databinding.view

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityProfileBinding
import com.medbiz.core.databinding.viewModel.ProfileViewModel
import com.medbiz.core.singleton.Preferences
import kotlinx.android.synthetic.main.terms_bar.*
import java.text.SimpleDateFormat
import java.util.*


class ProfileActivity : AppCompatActivity() {
    var tag = ProfileActivity::class.java.name
    private lateinit var binding: ActivityProfileBinding
    private lateinit var viewModel: ProfileViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_profile)
        viewModel = ViewModelProvider(this).get(ProfileViewModel::class.java)

        binding.viewModel = viewModel
        setSupportActionBar(binding.toolbar)
        supportActionBar!!.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.back)
        }

        binding.profileSlideImage = R.drawable.profile_1

        viewModel.userMe.observe(this, Observer { userMe ->
            if(userMe != null) {
                binding.userName.text = userMe.userName
                binding.addAccount.isVisible = false
            } else {
                binding.userName.text = resources.getText(R.string.noUserName)
                binding.addAccount.isVisible = true
            }
        })

        viewModel.userGender.observe(this, Observer { gender ->
            if(!Preferences.userInfoCompleteFlag) binding.birthdayButton.performClick()
            else binding.genderButton.text = gender
        })

        viewModel.userBirthday.observe(this, Observer { birthday ->
            if(!Preferences.userInfoCompleteFlag) binding.heightButton.performClick()
            else binding.birthdayButton.text = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(birthday.toLong()))
        })

        viewModel.userHeight.observe(this, Observer { height ->
            if(!Preferences.userInfoCompleteFlag) binding.weightButton.performClick()
            else binding.heightButton.text = height
        })

        viewModel.userWeight.observe(this, Observer { weight ->
            if(!Preferences.userInfoCompleteFlag) binding.genderButton.performClick()
            else binding.weightButton.text = weight
        })
    }
}

package com.medbiz.core.databinding.viewModel

import android.app.Application
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.content.*
import android.os.IBinder
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.medbiz.core.databinding.model.entity.GlucoseEntity
import com.medbiz.core.databinding.model.repository.GlucoseRepository
import com.medbiz.core.databinding.view.InputGlucoseActivity
import com.medbiz.core.le.GlucoseGattAttributes
import com.medbiz.core.le.GlucoseService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch


class DisplayGlucoseViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = DisplayGlucoseViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val repository = GlucoseRepository(application)
    var glucose = repository.getLatestMeasuredData()

    var latestMeasuredDataSequence: Long? = null
    private var mService: GlucoseService? = null
    var mGlsService: BluetoothGattService? = null
    var mGlsChar: BluetoothGattCharacteristic? = null
    var mGccChar: BluetoothGattCharacteristic? = null
    var mRacpChar: BluetoothGattCharacteristic? = null
    private var mConnection = false
    private var mConnectedDeviceName: String? = null

    init {
        scope.launch {
            latestMeasuredDataSequence = repository.getLatestMeasuredDataSequence()
            if(latestMeasuredDataSequence == null) latestMeasuredDataSequence = 0
            //Log.i(tag, "Glucose table data size is $latestMeasuredDataSequence")
        }
    }

    private val mServiceConnection= object : ServiceConnection {
        override fun onServiceConnected(componentName: ComponentName, service: IBinder) {
            mService = (service as GlucoseService.LocalBinder).service
            //Log.i(tag, "GlucoseService::onServiceConnected() Success !! " + mService.toString())
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            //Log.i(tag, "GlucoseService::onServiceDisconnected() Success !! " + mService.toString())
            mService?.disconnect()
        }
    }

    private val mGattUpdateReceiver= object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            val action = intent.action
            if (GlucoseGattAttributes.ACTION_GATT_CONNECTED == action) {
                //Log.i(tag, "[ACTION_GATT_CONNECTED] ")
            } else if (GlucoseGattAttributes.ACTION_GATT_DISCONNECTED == action) {
                //Log.i(tag, "[ACTION_GATT_DISCONNECTED] ")
                mConnection = false
            } else if (GlucoseGattAttributes.ACTION_GATT_SERVICES_DISCOVERED == action) {
                //Log.i(tag, "[ACTION_GATT_SERVICES_DISCOVERED] ")
                mGlsService = mService!!.getGattService(GlucoseGattAttributes.GLUCOSE_SERVICE_UUID)
                //Log.i(tag, "mGlsService is : " + mGlsService!!.uuid.toString())
                mGlsChar = mGlsService!!.getCharacteristic(GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CHAR_UUID)
                //Log.i(tag, "mGlsChar is : " + mGlsChar!!.uuid.toString())
                mGccChar = mGlsService!!.getCharacteristic(GlucoseGattAttributes.GLUCOSE_CONTEXT_CHAR_UUID)
                //Log.i(tag, "mGccChar is : " + mGccChar!!.uuid.toString())
                mRacpChar = mGlsService!!.getCharacteristic(GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CHAR_UUID)
                //Log.i(tag, "mRacpChar is : " + mRacpChar!!.uuid.toString())
                val mGlsDesc = mGlsChar!!.getDescriptor(GlucoseGattAttributes.GLUCOSE_MEASUREMENT_CCCD_UUID)
                //Log.i(tag, "mGlsChar setCharacteristicNotification() : " + mGlsDesc.uuid.toString())
                mService!!.setCharacteristicNotification(mGlsChar!!, true)
            } else if (GlucoseGattAttributes.ACTION_ENABLE_GLUCOSE_CONTEXT_NOTIFICATION == action) {
                val mGccDesc = mGccChar!!.getDescriptor(GlucoseGattAttributes.GLUCOSE_CONTEXT_CCCD_UUID)
                //Log.i(tag, "mGccChar setCharacteristicNotification() : " + mGccDesc.uuid.toString())
                mService!!.setCharacteristicNotification(mGccChar!!, true)
            } else if (GlucoseGattAttributes.ACTION_ENABLE_RECORD_ACCESS_CONTROL_POINT_INDICATION == action) {
                //Log.i(tag, "[ACTION_ENABLE_RECORD_ACCESS_CONTROL_POINT_INDICATION] ")
                val mRacpDesc = mRacpChar!!.getDescriptor(GlucoseGattAttributes.RECORD_ACCESS_CONTROL_POINT_CCCD_UUID)
                mService!!.setCharacteristicIndication(mRacpChar!!, true)
            } else if (GlucoseGattAttributes.ACTION_WRITE_RECORD_ACCESS_CONTROL_POINT_CHAR == action) {
                //Log.i(tag, "[ACTION_WRITE_RECORD_ACCESS_CONTROL_POINT_CHAR] ")
                mRacpChar!!.value = byteArrayOf(0x01, 0x03, 0x01, (latestMeasuredDataSequence!!.rem(256)).toByte(), (latestMeasuredDataSequence!! / 256).toByte())
                mService!!.writeCharacteristic(mRacpChar)
            } else if (GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_MEASUREMENT_CHAR == action) {
                //Log.i(tag, "[ACTION_CHANGED_GLUCOSE_MEASUREMENT_CHAR] ")
                val measurementTime = intent.getLongExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT_TIME, 0)
                val sequence = intent.getLongExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT_SEQUENCE, 0)
                val glucose = intent.getIntExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_MEASUREMENT, 0)
                val bloodType = intent.getStringExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_BLOOD_TYPE)
                val sampleLocation = intent.getStringExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_SAMPLE_LOCATION)
                //Log.i(tag, "[EXTRA_GLUCOSE_MEASUREMENT_TIME] : $measurementTime")
                //Log.i(tag, "[EXTRA_GLUCOSE_MEASUREMENT_SEQUENCE] : $sequence")
                //Log.i(tag, "[EXTRA_GLUCOSE_MEASUREMENT] : $glucose")
                //Log.i(tag, "[EXTRA_GLUCOSE_BLOOD_TYPE] : $bloodType")
                //Log.i(tag, "[EXTRA_GLUCOSE_SAMPLE_LOCATION] : $sampleLocation")

                latestMeasuredDataSequence = sequence

                scope.launch {
                    val entity = GlucoseEntity(
                            sequence = sequence,
                            glucose = glucose,
                            contextMeal = null,
                            insulin = null,
                            timeStamp = measurementTime,
                            pill = null,
                            memo = null
                    )
                    repository.insert(entity)
                }


            } else if (GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_CONTEXT_CHAR == action) {
                //Log.i(tag, "[ACTION_CHANGED_GLUCOSE_CONTEXT_CHAR] ")

                val sequence = intent.getLongExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_SEQUENCE, 0)
                val contextMeal = intent.getStringExtra(GlucoseGattAttributes.EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT)
                //Log.i(tag, "[EXTRA_GLUCOSE_CONTEXT_SEQUENCE] : $sequence")
                //Log.i(tag, "[EXTRA_GLUCOSE_CONTEXT_MEAL_PRESENT] : $contextMeal")
                scope.launch {
                    val entity = GlucoseEntity(
                            sequence = sequence,
                            glucose = 0,
                            contextMeal = contextMeal,
                            insulin = null,
                            timeStamp = 0,
                            pill = null,
                            memo = null
                    )
                    repository.insert(entity)
                }
            } else if (GlucoseGattAttributes.ACTION_FIND_DEVICE == action) {
                if (!mConnection) {
                    val res: Boolean = mService!!.connect(intent.getStringExtra(GlucoseGattAttributes.EXTRA_DATA_DEVICE_ADDRESS))
                    if (res) {
                        mConnectedDeviceName = intent.getStringExtra(GlucoseGattAttributes.EXTRA_DATA_DEVICE_NAME)
                        //Log.i(tag, "[ACTION_FIND_DEVICE] res : $mConnectedDeviceName")
                        mConnection = true
                    } else {
                        mConnection = false
                    }
                    //Log.i(tag, "BroadcastReceiver: ACTION_FIND_DEVICE res : $res")
                }
            }
        }
    }

    private fun makeGattUpdateIntentFilter(): IntentFilter {
        val intentFilter = IntentFilter()
        intentFilter.addAction(GlucoseGattAttributes.ACTION_GATT_CONNECTED)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_GATT_CONNECTED)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_GATT_DISCONNECTED)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_GATT_SERVICES_DISCOVERED)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_DATA_AVAILABLE)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_FIND_DEVICE)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_WRITE_RECORD_ACCESS_CONTROL_POINT_CHAR)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_MEASUREMENT_CHAR)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_CHANGED_GLUCOSE_CONTEXT_CHAR)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_CHANGED_RECORD_ACCESS_CONTROL_POINT_CHAR)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_ENABLE_GLUCOSE_CONTEXT_NOTIFICATION)
        intentFilter.addAction(GlucoseGattAttributes.ACTION_ENABLE_RECORD_ACCESS_CONTROL_POINT_INDICATION)
        return intentFilter
    }

    // The code below is BLE control source
    fun bindService(application: Application) {
        var intent = Intent(application, GlucoseService::class.java)
        application.registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter())
        application.bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE)
    }

    fun unbindService(application: Application) {
        application.unregisterReceiver(mGattUpdateReceiver);
        application.unbindService(mServiceConnection)
    }

    fun inputGlucoseData(view: View){
        var intent = Intent(view.context, InputGlucoseActivity::class.java)
        ContextCompat.startActivity(view.context, intent, null)
    }
}

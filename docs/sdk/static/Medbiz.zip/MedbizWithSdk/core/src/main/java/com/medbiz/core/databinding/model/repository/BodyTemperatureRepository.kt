package com.medbiz.core.databinding.model.repository

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.databinding.model.dao.BodyTemperatureDao
import com.medbiz.core.databinding.model.database.AppDB
import com.medbiz.core.databinding.model.entity.BodyTemperatureEntity

class BodyTemperatureRepository(application: Application) {
    private var bodyTemperatureDao = AppDB.getInstance(application)!!.bodyTemperatureDao()
    fun getDBInstance(): AppDB.Companion {
        return AppDB
    }

    suspend fun getAll(): List<BodyTemperatureEntity> {
        return bodyTemperatureDao.getAll()
    }

    suspend fun getSize(): Int {
        return bodyTemperatureDao.getSize()
    }

    fun getLatestMeasuredData(): LiveData<BodyTemperatureEntity> {
        return bodyTemperatureDao.getLatestMeasuredData()
    }

    suspend fun insert(bloodPressureEntity: BodyTemperatureEntity) {
        bodyTemperatureDao.insert(bloodPressureEntity)
    }

    suspend fun deleteAll() {
        bodyTemperatureDao.deleteAll()
    }

    suspend fun delete(bloodPressureEntity: BodyTemperatureEntity) {
        bodyTemperatureDao.delete(bloodPressureEntity)
    }

    suspend fun update(bloodPressureEntity: BodyTemperatureEntity) {
        bodyTemperatureDao.update(bloodPressureEntity)
    }
}


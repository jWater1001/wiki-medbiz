package com.medbiz.core.databinding.recyclerview.item

class GlucoseContextMealItem(
        var contextMealDescription: String,
        var contextMealIcon: Int,
        var contextMealReversalIcon: Int,
        var contextMealValue: String) {

}
package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.CheckBox
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.databinding.view.TermsActivity
import com.medbiz.core.singleton.Preferences
import kotlinx.coroutines.withContext

class TermsViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = TermsViewModel::class.java.name
    private var termsAgreementCheckBox:Boolean = false
    private var privacyAgreementCheckBox:Boolean = false
    var locationAgreementCheckBox:Boolean = false
    var isAgree = MutableLiveData<Boolean>()
    var buttonLiveData = MutableLiveData<Boolean>()

    fun onNextButton() {
        // DB에 플래그 내용 저장 또는 글로벌 변수로 저장
        Preferences.agreementTerms = true
        if(locationAgreementCheckBox) {
            Preferences.agreementLocationAccess = true
        }
        buttonLiveData.postValue(true)

    }

    fun onTermsAgreementCheckBox(view: View) {
        termsAgreementCheckBox = (view as CheckBox).isChecked
        isAgree.postValue(termsAgreementCheckBox && privacyAgreementCheckBox)

    }

    fun onPrivacyAgreementCheckBox(view: View) {
        privacyAgreementCheckBox = (view as CheckBox).isChecked
        isAgree.postValue(termsAgreementCheckBox && privacyAgreementCheckBox)
    }

    companion object {
        const val REQUEST_ENABLE_BT = 100
        const val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 200
    }

}
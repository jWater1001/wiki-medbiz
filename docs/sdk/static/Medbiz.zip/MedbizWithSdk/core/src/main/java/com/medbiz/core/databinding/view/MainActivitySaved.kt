package com.medbiz.core.databinding.view

import androidx.appcompat.app.AppCompatActivity

class MainActivitySaved : AppCompatActivity() {
//    var tag = MainActivitySaved::class.java.name
//
//    lateinit var binding: ActivityMainSavedBinding
//    lateinit var eventViewModel: EventViewModel
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//
//        binding = DataBindingUtil.setContentView(this, R.layout.activity_main_saved)
//
//        val adapter = EventAdapter()
//
//        binding.recyclerView.apply {
//            this.layoutManager = LinearLayoutManager(this.context)
//            this.adapter = adapter
//        }
//
//        eventViewModel = ViewModelProvider(this).get(EventViewModel::class.java)
//        eventViewModel.mutableLiveData.observe(this,  Observer<List<EventEntity>> { eventEntityList ->
//            adapter.setEventEntityList(eventEntityList)
//        })
//        eventViewModel.accessTokenLiveData.observe(this, Observer<OAuthToken> { mOAuthToken ->
//            Log.d(tag, "OAuthToken 세팅됨")
//            Log.d(tag, "accessToken : ${mOAuthToken.accessToken}")
//            Log.d(tag, "tokenType : ${mOAuthToken.tokenType}")
//            Log.d(tag, "expiresIn : ${mOAuthToken.expiresIn}")
//            Log.d(tag, "refreshToken : ${mOAuthToken?.refreshToken}")
//            Log.d(tag, "scope : ${mOAuthToken?.scope}")
//        })
//
//        binding.eventViewModel = eventViewModel
//
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_OK) {
//            when (requestCode) {
//                1004 -> {
//                    var mOAuthToken = data?.getSerializableExtra("OAuthToken") as OAuthToken
//                    eventViewModel.accessTokenLiveData.postValue(mOAuthToken)
//                }
//                1005 -> {
//                    var mOAuthToken = data?.getSerializableExtra("OAuthToken") as OAuthToken
//                    eventViewModel.accessTokenLiveData.postValue(mOAuthToken)
//                }
//            }
//        }
//    }
}
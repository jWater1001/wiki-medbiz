package com.medbiz.core.databinding.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.medbiz.core.databinding.view.DisplayBloodPressureFragment
import com.medbiz.core.databinding.view.DisplayBloodPressureStaticsFragment

class BloodPressurePagerAdapter(fm: FragmentManager, behavior: Int) : FragmentPagerAdapter(fm, behavior) {

    private var titles = arrayOf("기록", "전체기록")
    private var fragments: ArrayList<Fragment> = arrayListOf()

    init {
        fragments.add(DisplayBloodPressureFragment())
        fragments.add(DisplayBloodPressureStaticsFragment())
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return this.titles[position]
    }

    override fun getItem(position: Int): Fragment {
        return this.fragments[position]
    }

    override fun getCount(): Int {
        return this.fragments.size
    }
}
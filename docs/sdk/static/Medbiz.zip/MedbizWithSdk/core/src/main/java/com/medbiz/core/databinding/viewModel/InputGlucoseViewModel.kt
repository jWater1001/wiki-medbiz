package com.medbiz.core.databinding.viewModel

import android.app.Activity
import android.app.Application
import android.util.Log
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.medbiz.core.R
import com.medbiz.core.databinding.model.entity.GlucoseEntity
import com.medbiz.core.databinding.model.repository.GlucoseRepository
import com.medbiz.core.databinding.recyclerview.adapter.GlucoseContextMealAdapter
import com.medbiz.core.databinding.recyclerview.adapter.HorizontalPickerAdapter
import com.medbiz.core.databinding.recyclerview.item.GlucoseContextMealItem
import com.medbiz.core.le.GlucoseGattAttributes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class InputGlucoseViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = InputGlucoseViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val repository = GlucoseRepository(application)

    val glucoseContextMealItem = listOf(
            GlucoseContextMealItem("공복", R.drawable.fasting, R.drawable.reversal_fasting, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_FASTING),
            GlucoseContextMealItem("식전", R.drawable.preprandial, R.drawable.reversal_preprandial, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_PREPRANDIAL),
            GlucoseContextMealItem("식후", R.drawable.postprandial, R.drawable.reversal_postprandial, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_POSTPRANDIAL),
            GlucoseContextMealItem("취침 전", R.drawable.bedtime, R.drawable.reversal_bedtime, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_BEDTIME),
            GlucoseContextMealItem("평상 시", R.drawable.causal, R.drawable.reversal_causal, GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_CASUAL))
    var localeTime = MutableLiveData<String>()
    var pickeredGlucose = MutableLiveData<Int>()
    var insulin = MutableLiveData<Double>()
    var pillUsage = MutableLiveData<String>()
    var pillUsageInfo = arrayOf("사용 안 함", "복용함", "복용 안 함")
    var memo = MutableLiveData<String>()
    val glucoseAdapter = HorizontalPickerAdapter()
    val glucoseContextMealAdapter = GlucoseContextMealAdapter()
    private var localeTimeDetail = Date().time

    init {
        localeTime.postValue(SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분", Locale.getDefault()).format(Date()))
        pickeredGlucose.postValue(100)
        glucoseAdapter.setItemList((16..720).toList())
        glucoseAdapter.setMax(716)
        glucoseContextMealAdapter.setItemList(glucoseContextMealItem)


    }

    fun onClickSavedButton(view: View) {
        var sdf = SimpleDateFormat("yyyy년 MM월 dd일 (E) a HH시 mm분");
        var timestamp = sdf.parse(localeTime.value).time
        Log.d(tag, "\r\n")
        Log.d(tag, "localeTime  : ${localeTime.value}")
        Log.d(tag, "Glucose     : ${pickeredGlucose.value}")
        Log.d(tag, "pillUsage   : ${pillUsage.value}")
        Log.d(tag, "memo        : ${memo.value}")
        Log.d(tag, "insulin     : ${insulin.value}")
        Log.d(tag, "contextMeal : ${glucoseContextMealAdapter.selectedContextMeal}")
        var data = GlucoseEntity(
                sequence = -1,
                timeStamp = localeTimeDetail,
                glucose = pickeredGlucose.value!!,
                contextMeal = glucoseContextMealAdapter.selectedContextMeal,
                insulin = insulin.value,
                pill = pillUsage.value,
                memo = memo.value
        )
        scope.launch {
            repository.insert(data)
        }
        (view.context as Activity).onBackPressed()
    }

    fun onClickCanceledButton(view: View) {
        (view.context as Activity).onBackPressed()
    }
}
package com.medbiz.core.healthdata

class Glucose: HealthConstants() {
    val healthDataType = "com.medbiz.core.healthdata.Glucose"
    var glucose = 0

    init {
        super.dataType = GLUCOSE
    }

}

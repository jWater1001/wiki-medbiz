package com.medbiz.core.databinding.model.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.entity.GlucoseEntity

@Dao
interface GlucoseDao {

    @Query("SELECT * FROM glucose")
    suspend fun getAll(): List<GlucoseEntity>

    @Query("SELECT COUNT(id) FROM glucose")
    suspend fun getSize(): Int

    @Query("SELECT MAX(sequence) FROM glucose")
    suspend fun getLatestMeasuredDataSequence(): Long

    @Query("SELECT * FROM glucose ORDER BY timeStamp DESC limit 1")
    fun getLatestMeasuredData(): LiveData<GlucoseEntity>

    @Query("SELECT * FROM glucose WHERE timeStamp=0 AND glucose=0 ORDER BY id DESC limit 1")
    fun getContextMealBySequence(): LiveData<GlucoseEntity>

    @Query("DELETE FROM glucose")
    suspend fun deleteAll()

    @Query("SELECT * FROM glucose WHERE sequence=:sequence")
    suspend fun getDataBySequence(sequence: Long): GlucoseEntity?

    @Query("UPDATE glucose SET contextMeal=:contextMeal where id=:id")
    suspend fun updateContextMeal(id: Int, contextMeal: String?)
    
    @Query("UPDATE glucose SET glucose=:glucose, timeStamp=:timeStamp  where id=:id")
    suspend fun updateGlucose(id: Int, glucose: Int, timeStamp: Long)

    @Transaction
    @Insert
    suspend fun insert(vararg glucoseEntity: GlucoseEntity)
    
    @Delete
    suspend fun delete(vararg glucoseEntity: GlucoseEntity)

    @Transaction
    @Update
    suspend fun update(vararg glucoseEntity: GlucoseEntity)
}
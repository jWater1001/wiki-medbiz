package com.medbiz.core.databinding.viewModel

import android.app.Application
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.content.*
import android.os.IBinder
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.medbiz.core.databinding.model.entity.BodyTemperatureEntity
import com.medbiz.core.databinding.model.repository.BodyTemperatureRepository
import com.medbiz.core.databinding.view.InputBodyTemperatureActivity
import com.medbiz.core.le.BodyTemperatureGattAttributes
import com.medbiz.core.le.BodyTemperatureService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.*

class DisplayBodyTemperatureViewModel(application: Application) : AndroidViewModel(application) {
    private val tag = DisplayBodyTemperatureViewModel::class.java.name
    private val repository = BodyTemperatureRepository(application)
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)

    private var mConnectedDeviceName: String? = null
    private var mService: BodyTemperatureService? = null
    var mBtService: BluetoothGattService? = null
    var mBtChar: BluetoothGattCharacteristic? = null
    var bodyTemperature = repository.getLatestMeasuredData()

    init {

    }

    private val mServiceConnection= object : ServiceConnection {
        override fun onServiceConnected(componentName: ComponentName, service: IBinder) {
            mService = (service as BodyTemperatureService.LocalBinder).service
            Log.i(tag, "BodyTemperatureService::onServiceConnected() Success !! " + mService.toString())
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            Log.i(tag, "BodyTemperatureService::onServiceDisconnected() Success !! " + mService.toString())
            mService?.disconnect()
        }
    }
    
    private val mGattUpdateReceiver= object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (BodyTemperatureGattAttributes.ACTION_GATT_CONNECTED == action) {
                Log.d(tag, "[ACTION_GATT_CONNECTED]")
            } else if (BodyTemperatureGattAttributes.ACTION_GATT_DISCONNECTED == action) {
                Log.d(tag, "[ACTION_GATT_DISCONNECTED]")
            } else if (BodyTemperatureGattAttributes.ACTION_GATT_SERVICES_DISCOVERED == action) {
                Log.d(tag, "[ACTION_GATT_SERVICES_DISCOVERED] ")
                mBtService = mService!!.getGattService(BodyTemperatureGattAttributes.BODY_TEMPERATURE_SERVICE_UUID)
                Log.d(tag, "mBlpService is : " + mBtService!!.uuid.toString())
                mBtChar = mBtService!!.getCharacteristic(BodyTemperatureGattAttributes.BODY_TEMPERATURE_MEASUREMENT_CHAR_UUID)
                Log.d(tag, "mBtChar is : " + mBtChar!!.uuid.toString())
                Log.d(tag, "BroadcastReceiver: ACTION_GATT_CHARACTERISTIC_UUID : " + mBtChar!!.uuid.toString())
                val mBtDescriptor: BluetoothGattDescriptor = mBtChar!!.getDescriptor(BodyTemperatureGattAttributes.BODY_TEMPERATURE_MEASUREMENT_CCCD_UUID)
                Log.d(tag, "BroadcastReceiver: ACTION_GATT_CCCD_UUID : " + mBtDescriptor.uuid.toString())
                mService!!.setCharacteristicIndication(mBtChar!!, true)
            } else if (BodyTemperatureGattAttributes.ACTION_DATA_AVAILABLE == action) {
                Log.d(tag, "BroadcastReceiver: ACTION_DATA_AVAILABLE New Data!!! ")
                val bodyTemperature = intent.getDoubleExtra(BodyTemperatureGattAttributes.EXTRA_BODY_TEMPERATURE, .0)
                val timeStamp = Date().time

                var measuredData = BodyTemperatureEntity(
                        bodyTemperature = bodyTemperature,
                        context = "Forehead",
                        timeStamp = timeStamp,
                        memo = null
                )

                scope.launch {
                    // call DB insert
                    repository.insert(measuredData)
                    // call Health API
                }


            } else if (BodyTemperatureGattAttributes.ACTION_FIND_DEVICE == action) {
                val deviceMacAddress = intent.getStringExtra(BodyTemperatureGattAttributes.EXTRA_DATA_DEVICE_ADDRESS)
                val res: Boolean = mService!!.connect(deviceMacAddress)
                Log.d(tag, "[ACTION_FIND_DEVICE] @" + deviceMacAddress + "res : " + res)
                if (res) {
                    mConnectedDeviceName = intent.getStringExtra(BodyTemperatureGattAttributes.EXTRA_DATA_DEVICE_NAME)
                    Log.d(tag, "[ACTION_FIND_DEVICE] mConnectedDeviceName : $mConnectedDeviceName")
                } else {
                }
            }
        }
    }

    private fun makeGattUpdateIntentFilter(): IntentFilter {
        val intentFilter = IntentFilter()
        intentFilter.addAction(BodyTemperatureGattAttributes.ACTION_GATT_CONNECTED)
        intentFilter.addAction(BodyTemperatureGattAttributes.ACTION_GATT_DISCONNECTED)
        intentFilter.addAction(BodyTemperatureGattAttributes.ACTION_GATT_SERVICES_DISCOVERED)
        intentFilter.addAction(BodyTemperatureGattAttributes.ACTION_DATA_AVAILABLE)
        intentFilter.addAction(BodyTemperatureGattAttributes.ACTION_FIND_DEVICE)
        return intentFilter
    }

    // The code below is BLE control source
    fun bindService(application: Application) {
        var intent = Intent(application, BodyTemperatureService::class.java)
        application.registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter())
        application.bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE)

    }

    fun unbindService(application: Application) {
        application.unregisterReceiver(mGattUpdateReceiver);
        application.unbindService(mServiceConnection)

    }

    fun inputBodyTemperatureData(view: View){
        var intent = Intent(view.context, InputBodyTemperatureActivity::class.java)
        ContextCompat.startActivity(view.context, intent, null)
    }
}

package com.medbiz.core.databinding.viewModel

import android.app.Application
import android.util.Log
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.github.mikephil.charting.charts.PieChart
import com.medbiz.core.databinding.model.entity.BloodPressureEntity
import com.medbiz.core.databinding.model.repository.BloodPressureRepository
import com.medbiz.core.databinding.model.repository.GlucoseRepository
import com.medbiz.core.healthdata.*
import com.medbiz.core.databinding.recyclerview.adapter.HealthConstantAdapter
import com.medbiz.core.databinding.recyclerview.adapter.MyDeviceAdapter
import com.medbiz.core.singleton.Preferences
import com.medbiz.sdk.openapi.MyDevice
import com.medbiz.sdk.openapi.Password
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.MyDeviceRepository
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch


class MyDeviceViewModel (application: Application) : AndroidViewModel(application) {
    private val tag = MyDeviceViewModel::class.java.name
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private val myDevicesRepository = MyDeviceRepository(application)
    private val oAuthTokenRepository = OAuthTokenRepository(application)
    private var client = MyDevice(myDevicesRepository)

    var adapter = MyDeviceAdapter()
    var myDevice = myDevicesRepository.getAllDevices()
    var oauthToken = oAuthTokenRepository.getOAuthTokenFromDB()

    init {
        scope.launch {
            val token = oAuthTokenRepository.getOAuthToken()
            if(token != null ) {
                client.getMyDeviceList("Bearer " + token.accessToken as String)
            }

        }
    }

}
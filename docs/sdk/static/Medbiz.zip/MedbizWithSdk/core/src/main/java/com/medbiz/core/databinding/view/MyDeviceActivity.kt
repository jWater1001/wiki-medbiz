package com.medbiz.core.databinding.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.medbiz.core.R
import com.medbiz.core.databinding.ActivityMyDeviceBinding
import com.medbiz.core.databinding.viewModel.MyDeviceViewModel

class MyDeviceActivity : AppCompatActivity() {

    var tag = MyDeviceActivity::class.java.name
    lateinit var binding: ActivityMyDeviceBinding
    private lateinit var viewModel: MyDeviceViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_device)
        viewModel = ViewModelProvider(this).get(MyDeviceViewModel::class.java)
        binding.viewModel = viewModel

        val linearLayoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = linearLayoutManager
        binding.recyclerView.adapter = viewModel.adapter

        viewModel.myDevice.observe(this, Observer { deviceList ->
            viewModel.adapter.setItemList(deviceList)
        })

    }
}

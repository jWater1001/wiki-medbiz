package com.medbiz.core

import android.app.Application
import com.medbiz.core.singleton.Preferences

class App: Application() {

    override fun onCreate() {
        super.onCreate()
        Preferences.init(this)
    }
}
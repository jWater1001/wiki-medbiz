package com.medbiz.core.databinding.view

import android.os.Bundle
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.medbiz.core.R
import com.medbiz.core.databinding.FragmentDisplayGlucoseBinding
import com.medbiz.core.databinding.adapter.bindingImage
import com.medbiz.core.databinding.viewModel.DisplayGlucoseViewModel
import com.medbiz.core.le.GlucoseGattAttributes
import java.text.SimpleDateFormat
import java.util.*


/**
 * A simple [Fragment] subclass.
 */
class DisplayGlucoseFragment : Fragment() {
    private lateinit var viewModel: DisplayGlucoseViewModel
    lateinit var binding: FragmentDisplayGlucoseBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_display_glucose, container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(DisplayGlucoseViewModel::class.java)
        binding.viewModel = viewModel

        viewModel.glucose.observe(viewLifecycleOwner,  Observer { data ->
            if(data == null) {
                binding.noDataTextView.isVisible = true
                binding.latestMeasuredGlucose.isVisible = false
                binding.latestMeasuredTime.isVisible = false
                binding.contextMealIcon.isVisible = false
                binding.contextMealIconDescription.isVisible = false
            } else {
                binding.noDataTextView.isVisible = false
                binding.latestMeasuredGlucose.isVisible = true
                binding.latestMeasuredTime.isVisible = true
                binding.contextMealIcon.isVisible = true
                binding.contextMealIconDescription.isVisible = true

                val glucoseValue = SpannableString(data.glucose.toString() + " mg/dL")
                glucoseValue.setSpan(RelativeSizeSpan(0.3f), glucoseValue.length-5, glucoseValue.length, 0)
                binding.latestMeasuredGlucose.text = glucoseValue
                binding.latestMeasuredTime.text = SimpleDateFormat("yyyy년 MM월 dd일(E) HH:mm").format(Date(data.timeStamp))

                when(data.contextMeal){
                    GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_FASTING -> {
                        binding.contextMealIcon.setImageResource(R.drawable.fasting)
                        binding.contextMealIconDescription.text = "공복"
                    }
                    GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_PREPRANDIAL -> {
                        binding.contextMealIcon.setImageResource(R.drawable.preprandial)
                        binding.contextMealIconDescription.text = "식전"
                    }
                    GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_POSTPRANDIAL -> {
                        binding.contextMealIcon.setImageResource(R.drawable.postprandial)
                        binding.contextMealIconDescription.text = "식후"
                    }
                    GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_BEDTIME -> {
                        binding.contextMealIcon.setImageResource(R.drawable.bedtime)
                        binding.contextMealIconDescription.text = "수면 전"
                    }
                    GlucoseGattAttributes.GLUCOSE_MEAL_PRESENT_CASUAL -> {
                        binding.contextMealIcon.setImageResource(R.drawable.causal)
                        binding.contextMealIconDescription.text = "평상시"
                    }
                }
            }
        })

    }

    override fun onResume() {
        super.onResume()
        viewModel.bindService(activity!!.application)
    }
    override fun onStop() {
        super.onStop()
        viewModel.unbindService(activity!!.application)
    }
}

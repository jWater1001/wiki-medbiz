package com.medbiz.core.databinding.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "blood_pressure", indices = [Index(value = ["timeStamp"])])
data class BloodPressureEntity(
        @ColumnInfo(name = "systolic") var systolic: Int,
        @ColumnInfo(name = "diastolic") var diastolic: Int,
        @ColumnInfo(name = "pulse") var pulse: Int?,
        @ColumnInfo(name = "map") var map: Int?,
        @ColumnInfo(name = "timeStamp") var timeStamp: Long,
        @ColumnInfo(name = "pill") var pill: String?,
        @ColumnInfo(name = "memo") var memo: String?)
{
    @PrimaryKey(autoGenerate = true) var id: Int=0
}
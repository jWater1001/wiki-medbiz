package com.medbiz.core

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.medbiz.core.databinding.model.entity.GlucoseEntity
import com.medbiz.core.databinding.model.repository.GlucoseRepository
import kotlinx.coroutines.*
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException


@RunWith(AndroidJUnit4::class)
class RoomEntityInsertionUpdateTest {
    private var repository: GlucoseRepository? = null
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main + job)

    @Before
    fun createDb() {
        repository = GlucoseRepository(ApplicationProvider.getApplicationContext())
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        scope.launch {
            repository!!.getDBInstance().destroyInstance()
        }
    }

    @Test
    @Throws(Exception::class)
    fun writeUserAndReadInList() {
        scope.launch {
            for(i in 1..300) {
                val entity = GlucoseEntity(
                        i.toLong(),
                        130,
                        "8417868^MDC_CTXT_GLU_MEAL_PREPRANDIAL^MDC",
                        null,
                        1585806180000,
                        null,
                        null)
                repository!!.insert(entity)
                var data = repository!!.getDataBySequence(i.toLong())
                data!!.memo = "dsfdsfdsfds"
                repository!!.update(data)
            }
        }
    }
}
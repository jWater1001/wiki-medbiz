package com.medbiz.sdk.oauth

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.medbiz.sdk.openapi.entity.OAuthClient
import com.medbiz.sdk.openapi.entity.OAuthClientInformation
import com.medbiz.sdk.openapi.entity.OAuthToken
import com.medbiz.sdk.openapi.service.PasswordAuthenticationService
import kotlinx.coroutines.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import retrofit2.Response
import java.io.IOException
import java.util.concurrent.CountDownLatch


@RunWith(AndroidJUnit4::class)
class PasswordAuthenticationTest {
    private var clientInfo: OAuthClientInformation? = null
    private var client: OAuthClient? = null

    @Before
    fun setOAuthClient() {
        clientInfo = OAuthClientInformation(
                clientID = "95b10b20791e6c493aaf21a474c6c45c",
                clientSecret ="815da508fa084170a8df8f64173577c8",
                redirectURI = "https://localhost/auth",
                scope = "profile device",
                responseType = "token",
                grantType = "password")
        client = OAuthClient(clientInfo!!)
    }

    @After
    @Throws(IOException::class)
    fun finish() {

    }

    @Test
    @Throws(Exception::class)
    fun getAccessToken() {
        val job = SupervisorJob()
        val scope = CoroutineScope(Dispatchers.Main + job)
        val username = "gemscrc"
        val password = "gemscrc!234"
        var token: Response<OAuthToken>? = null
        val countDownLatch = CountDownLatch(1)
        var service: PasswordAuthenticationService? = PasswordAuthenticationService.invoke()
        scope.launch {
            token = service?.getAccessToken(
                    client!!.getBasicAuth(),
                    clientInfo!!.grantType!!,
                    username,
                    password)
            delay(3000)
            countDownLatch.countDown()
        }
        countDownLatch.await()
        assertNotNull(token)
        assertNotNull(token?.body())
        assertNotNull(token?.body()?.accessToken)
        service = null
    }

    @Test
    @Throws(Exception::class)
    fun getAccessTokenWithRefreshToken() {
        val job = SupervisorJob()
        val scope = CoroutineScope(Dispatchers.Main + job)
        val username = "gemscrc"
        val password = "gemscrc!234"
        val grantType = "refresh_token"
        var token: Response<OAuthToken>? = null
        var countDownLatch = CountDownLatch(1)
        val service = PasswordAuthenticationService.invoke()

        scope.launch {
            token = service.getAccessToken(
                    client!!.getBasicAuth(),
                    clientInfo!!.grantType!!,
                    username,
                    password)
            delay(3000)
            countDownLatch.countDown()
        }
        countDownLatch.await()
        assertNotNull(token)
        assertNotNull(token?.body())
        assertNotNull(token?.body()?.accessToken)
        assertNotNull(token?.body()?.refreshToken)

        countDownLatch = CountDownLatch(1)
        scope.launch {
            Log.d(Companion.TAG, client!!.getBasicAuth())
            Log.d(Companion.TAG, clientInfo!!.grantType!!)
            Log.d(Companion.TAG, clientInfo!!.scope)
            Log.d(Companion.TAG, token?.body()?.refreshToken!!)

            token = service.getAccessTokenWithRefreshToken(
                    client!!.getBasicAuth(),
                    grantType,
                    clientInfo!!.scope,
                    token?.body()?.refreshToken!!)
            delay(3000)
            countDownLatch.countDown()
        }
        countDownLatch.await()
        assertNotNull(token)
        assertNotNull(token?.body())
        assertNotNull((token?.body() as OAuthToken).accessToken)
        assertNotNull((token?.body() as OAuthToken).refreshToken)
    }

    companion object {
        private val TAG = PasswordAuthenticationTest::class.java.name
    }
}
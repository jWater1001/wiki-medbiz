package com.medbiz.sdk.openapi

import android.util.Log
import com.medbiz.sdk.openapi.entity.Item
import com.medbiz.sdk.openapi.entity.MyDevice
import com.medbiz.sdk.openapi.entity.MyDeviceEnrollment
import com.medbiz.sdk.openapi.service.MyDeviceService
import com.medbiz.sdk.room.entity.MyDeviceEntity
import com.medbiz.sdk.room.repository.MyDeviceRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyDevice(repository: MyDeviceRepository) {
    private val jobOpenApi = SupervisorJob()
    private val jobDB = SupervisorJob()
    private val openApiScope = CoroutineScope(Dispatchers.Main + jobOpenApi)
    private val dBScope = CoroutineScope(Dispatchers.Main + jobDB)
    private val repository = repository

    fun getMyDeviceList(accessToken: String, page: Int=0, size: Int=500) {
        openApiScope.launch {
            MyDeviceService.invoke().getMyDevices(accessToken, page, size).enqueue(object: Callback<MyDevice> {
                override fun onResponse(call: Call<MyDevice>, response: Response<MyDevice>) {
                    if (response.isSuccessful)
                    {
                        var devices = response.body()!!.items
                        dBScope.launch {
                            repository.deleteAllDevices()
                            for (device in devices) {
                                Log.d("getMyDeviceList", device.deviceNickname)
                                repository.insert(
                                        MyDeviceEntity(
                                                device.deviceMuid,
                                                device.deviceToken,
                                                device.deviceModel.modelMuid,
                                                device.deviceModel.modelImageUri,
                                                device.deviceSerialNumber,
                                                device.deviceNickname,
                                                device.version,
                                                device.deviceMacAddress
                                        )
                                )
                            }
                        }
                    } else {
                        // 400번 에러 나는 경우
                    }
                }

                override fun onFailure(call: Call<MyDevice>, t: Throwable) {
                }
            })
        }
    }

    fun deleteMyDevice(accessToken: String, deviceMuid: String) {
        openApiScope.launch {
            MyDeviceService.invoke().deleteMyDevice(accessToken, deviceMuid).enqueue(object: Callback<Item> {
                override fun onResponse(call: Call<Item>, response: Response<Item>) {
                    if (response.isSuccessful)
                    {
                        var device = response.body()!!.item
                        dBScope.launch {
                            var deletedEntity = repository.getMyDeviceInfo(device.deviceMuid)
                            repository.delete(deletedEntity)
                        }
                    }
                }

                override fun onFailure(call: Call<Item>, t: Throwable) {
                }
            })
        }
    }

    fun addMyDevice(accessToken: String,  deviceMuid: String, deviceNickname: String) {
        openApiScope.launch {
            var myDeviceEnrollment=  MyDeviceEnrollment(deviceMuid, deviceNickname)
            MyDeviceService.invoke().addMyDevice(accessToken, myDeviceEnrollment).enqueue(object: Callback<Item> {
                override fun onResponse(call: Call<Item>, response: Response<Item>) {
                    if (response.isSuccessful)
                    {
                        var device = response.body()!!.item
                        dBScope.launch {
                            var addedEntity = MyDeviceEntity(
                                    device.deviceMuid,
                                    device.deviceToken,
                                    device.deviceModel.modelMuid,
                                    device.deviceModel.modelImageUri,
                                    device.deviceSerialNumber,
                                    device.deviceNickname,
                                    device.version,
                                    device.deviceMacAddress
                            )
                            repository.insert(addedEntity)
                        }
                    }
                }

                override fun onFailure(call: Call<Item>, t: Throwable) {
                }
            })
        }
    }
}
package com.medbiz.sdk.room.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_me")
data class UserMeEntity(
        @ColumnInfo(name = "userMuid") var userMuid: String,
        @ColumnInfo(name = "userId") var userId: String,
        @ColumnInfo(name = "email") var email: String,
        @ColumnInfo(name = "createAt") var createAt: String?,
        @ColumnInfo(name = "userName") var userName: String?,
        @ColumnInfo(name = "birthDay") var birthDay: String,
        @ColumnInfo(name = "gender") var gender: String?,
        @ColumnInfo(name = "authorities") var authorities: String?,
        @ColumnInfo(name = "height") var height: Double?,
        @ColumnInfo(name = "weight") var weight: Double?,
        @ColumnInfo(name = "totalWalk") var totalWalk: Int?,
        @ColumnInfo(name = "activityLevel") var activityLevel: Int?
)
{
    @PrimaryKey(autoGenerate = false) var id: Int =0
}
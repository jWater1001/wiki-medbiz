package com.medbiz.sdk

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.medbiz.sdk.databinding.ActivityImplicitAuthenticationBinding

class ImplicitAuthenticationActivity : AppCompatActivity() {
    var tag = ImplicitAuthenticationActivity::class.java.name
    lateinit var binding: ActivityImplicitAuthenticationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_implicit_authentication)
        val intent = intent
        var webViewClient = ImplicitWebViewClient(this, intent.getSerializableExtra("OAuthImplicitInformation") as OAuthImplicitInformation)
        binding.implicitLoginWebView.settings.javaScriptEnabled = true
        binding.implicitLoginWebView.webViewClient = webViewClient
        binding.implicitLoginWebView.loadUrl(webViewClient.oauthClient.targetURI)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.implicitLoginWebView.removeAllViews()
        binding.implicitLoginWebView.clearHistory()
        binding.implicitLoginWebView.destroy()
    }
}



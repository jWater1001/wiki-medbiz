package com.medbiz.sdk.openapi.entity

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OAuthToken(
        @SerializedName("access_token")
        var accessToken: String,
        @SerializedName("token_type")
        var tokenType: String,
        @SerializedName("refresh_token")
        var refreshToken: String?,
        @SerializedName("expires_in")
        var expiresIn: Int,
        @SerializedName("scope")
        var scope: String?
): Serializable
package com.medbiz.sdk.room.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "my_device_list")
data class MyDeviceEntity(
        @ColumnInfo(name = "deviceMuid") var deviceMuid: String,
        @ColumnInfo(name = "deviceToken") var deviceToken: String,
        @ColumnInfo(name = "modelMuid") var modelMuid: String,
        @ColumnInfo(name = "modelImageUri") var modelImageUri: String?,
        @ColumnInfo(name = "deviceSerialNumber") var deviceSerialNumber: String?,
        @ColumnInfo(name = "deviceNickname") var deviceNickname: String?,
        @ColumnInfo(name = "version") var version: Int,
        @ColumnInfo(name = "deviceMacAddress") var deviceMacAddress: String?
){
    @PrimaryKey(autoGenerate = true) var id: Int =0
}
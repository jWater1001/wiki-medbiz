package com.medbiz.sdk.room.entity


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "oauth_token")
data class OAuthTokenEntity(
        @ColumnInfo(name = "access_token") var accessToken: String?,
        @ColumnInfo(name = "token_type") var tokenType: String?,
        @ColumnInfo(name = "refresh_token") var refreshToken: String?,
        @ColumnInfo(name = "expires_in") var expiresIn: Int?,
        @ColumnInfo(name = "scope") var scope: String?,
        @ColumnInfo(name = "response_code") var responseCode: Int=0,
        @PrimaryKey(autoGenerate = false) var id: Int=0
)
package com.medbiz.sdk.room.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.medbiz.sdk.room.entity.UserMeEntity

@Dao
interface UserMeDao {
    @Query("SELECT * FROM user_me WHERE id=:id")
    fun getUserMe(id: Int): LiveData<UserMeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vararg token: UserMeEntity)

    @Delete
    suspend fun delete(vararg token: UserMeEntity)

    @Update
    suspend fun update(token: UserMeEntity)
}
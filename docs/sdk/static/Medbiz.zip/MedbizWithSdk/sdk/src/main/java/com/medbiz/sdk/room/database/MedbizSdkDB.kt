package com.medbiz.sdk.room.database

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.medbiz.sdk.room.dao.MyDeviceDao
import com.medbiz.sdk.room.dao.OAuthTokenDao
import com.medbiz.sdk.room.dao.UserMeDao
import com.medbiz.sdk.room.entity.MyDeviceEntity
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.entity.UserMeEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
        entities = [
            OAuthTokenEntity::class,
            MyDeviceEntity::class,
            UserMeEntity::class
        ],
        version = 1,
        exportSchema = false)
abstract class MedbizSdkDB: RoomDatabase() {
    abstract fun oAuthTokenDao(): OAuthTokenDao
    abstract fun myDeviceDao(): MyDeviceDao
    abstract fun userMeDao(): UserMeDao

    companion object {
        private var INSTANCE: MedbizSdkDB? = null
        private val supervisorJob = SupervisorJob()
        private val coroutineScope = CoroutineScope(Dispatchers.Main + supervisorJob)
        fun getInstance(context: Context): MedbizSdkDB? {
            if (INSTANCE == null) {
                synchronized(MedbizSdkDB::class) {
                    Log.d(MedbizSdkDB::class.java.name, "MedbizSdkDB 생성")
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                            MedbizSdkDB::class.java, "medbiz_sdk.db")
                            .fallbackToDestructiveMigration()
                            .build()
                    Log.d(MedbizSdkDB::class.java.name, "MedbizSdkDB Instance 생성 완료")
                }
            }
            return INSTANCE
        }

        fun destroyInstance() {
            INSTANCE = null
            Log.d(MedbizSdkDB::class.java.name, "MedbizSdkDB Instance 삭제")
        }
    }


}
package com.medbiz.sdk.room.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.medbiz.sdk.room.dao.UserMeDao
import com.medbiz.sdk.room.database.MedbizSdkDB
import com.medbiz.sdk.room.entity.UserMeEntity

class UserMeRepository(application: Application) {
    private var userMeDao: UserMeDao = MedbizSdkDB.getInstance(application)!!.userMeDao()

    fun getDBInstance(): MedbizSdkDB.Companion {
        return MedbizSdkDB
    }

    fun getUserMeFromDB(id: Int=0): LiveData<UserMeEntity> {
        return userMeDao.getUserMe(id)
    }

    suspend fun insert(oAuthTokenEntity: UserMeEntity) {
        userMeDao.insert(oAuthTokenEntity)
    }

    suspend fun delete(oAuthTokenEntity: UserMeEntity) {
        userMeDao.delete(oAuthTokenEntity)
    }

    suspend fun update(oAuthTokenEntity: UserMeEntity) {
        userMeDao.update(oAuthTokenEntity)
    }
}


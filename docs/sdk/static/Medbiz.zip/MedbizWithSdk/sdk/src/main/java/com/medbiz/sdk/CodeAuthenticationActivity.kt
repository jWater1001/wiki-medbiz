package com.medbiz.sdk

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.medbiz.sdk.databinding.ActivityCodeAuthenticationBinding

class CodeAuthenticationActivity : AppCompatActivity() {
    var tag = CodeAuthenticationActivity::class.java.name
    lateinit var binding: ActivityCodeAuthenticationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = intent
        binding = DataBindingUtil.setContentView(this, R.layout.activity_code_authentication)
        val webViewClient = CodeWebViewClient(this, intent.getSerializableExtra("OAuthCodeInformation") as OAuthCodeInformation)
        binding.codeLoginWebView.settings.javaScriptEnabled = true
        binding.codeLoginWebView.webViewClient = webViewClient
        binding.codeLoginWebView.loadUrl(webViewClient.oauthClient.targetURI)
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.codeLoginWebView.removeAllViews()
        binding.codeLoginWebView.clearHistory()
        binding.codeLoginWebView.destroy()
    }
}

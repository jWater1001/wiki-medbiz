package com.medbiz.sdk.openapi.service

import com.medbiz.sdk.openapi.entity.OAuthToken
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface PasswordAuthenticationService {
    @Headers("Accept: application/json", "Content-Type: application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("oauth/token")
    suspend fun getAccessToken(
            @Header("Authorization") basicAuth: String,
            @Field("grant_type") grantType: String,
            @Field("username") username: String,
            @Field("password") password: String
    ): Response<OAuthToken>

    @Headers("Accept: application/json", "Content-Type: application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("oauth/token")
    suspend fun getAccessTokenWithRefreshToken(
            @Header("Authorization") basicAuth: String,
            @Field("grant_type") grantType: String,
            @Field("scope") scope: String,
            @Field("refresh_token") refreshToken: String
    ): Response<OAuthToken>

    companion object {
        private const val URL = "https://auth.medbiz.or.kr/"
        fun invoke(): PasswordAuthenticationService = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(PasswordAuthenticationService::class.java)
    }
}

package com.medbiz.sdk.openapi.entity

import com.google.gson.annotations.SerializedName

data class Device (
        var deviceMuid: String,
        var deviceToken: String,
        var developerUserMuid: String,
        var userRegistered: Boolean,
        var enabled: Boolean,
        var deviceModel: DeviceModel,
        var deviceSerialNumber: String,
        var deviceNickname: String,
        var version: Int,
        var usersMuid: List<String>,
        var ownerUserMuid: String,
        var deviceCreateDate: Long,
        var deviceModifyDate: Long,
        var deviceMacAddress: String
)

data class DeviceModel (
        var modelMuid: String,
        var modelSerialNumber: String,
        var developerUserMuid: String,
        var modelImageUri: String,
        var modelDuplicationRegistration: Boolean,
        var modelName: String,
        var modelDesc: String,
        var modelDeveloperName: String,
        var modelInfoImageUri: String,
        var modelBuyLink: String,
        var modelSize: String,
        var modelWeight: String,
        var status: String,
        var modelCreateDate: Long,
        var modelModifyDate: Long
)

data class MyDevice (
        var size: Int,
        var page: Int,
        var total: Int,
        var first: Boolean,
        var last: Boolean,
        var items: List<Device>
)

data class MyDeviceEnrollment(
        @SerializedName("deviceMuid")
        var deviceMuid: String,
        @SerializedName("deviceNickname")
        var deviceNickname: String
)

data class Item (
        @SerializedName("items")
        var item: Device
)


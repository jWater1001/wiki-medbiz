package com.medbiz.sdk.room.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.medbiz.sdk.room.entity.MyDeviceEntity

@Dao
interface MyDeviceDao {
    @Query("SELECT * FROM my_device_list")
    fun getAllDevices(): LiveData<List<MyDeviceEntity>>

    @Query("SELECT * FROM my_device_list where deviceMuid=:deviceMuid")
    suspend fun getMyDeviceInfo(deviceMuid: String): MyDeviceEntity

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(device: MyDeviceEntity)

    @Delete
    suspend fun delete(device: MyDeviceEntity)

    @Query("DELETE FROM my_device_list")
    suspend fun deleteAllDevices()

    @Update
    suspend fun update(device: MyDeviceEntity)
}
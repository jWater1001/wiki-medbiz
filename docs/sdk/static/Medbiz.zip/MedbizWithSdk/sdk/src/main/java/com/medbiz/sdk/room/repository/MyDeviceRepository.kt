package com.medbiz.sdk.room.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.medbiz.sdk.room.dao.MyDeviceDao
import com.medbiz.sdk.room.database.MedbizSdkDB
import com.medbiz.sdk.room.entity.MyDeviceEntity

class MyDeviceRepository(application: Application) {
    private var myDeviceDao: MyDeviceDao = MedbizSdkDB.getInstance(application)!!.myDeviceDao()

    fun getDBInstance(): MedbizSdkDB.Companion {
        return MedbizSdkDB
    }

    fun getAllDevices(): LiveData<List<MyDeviceEntity>> {
        return myDeviceDao.getAllDevices()
    }

    suspend fun getMyDeviceInfo(deviceMuid: String): MyDeviceEntity {
        return myDeviceDao.getMyDeviceInfo(deviceMuid)
    }

    suspend fun insert(myDeviceEntity: MyDeviceEntity) {
        myDeviceDao.insert(myDeviceEntity)
    }

    suspend fun delete(myDeviceEntity: MyDeviceEntity) {
        myDeviceDao.delete(myDeviceEntity)
    }

    suspend fun deleteAllDevices() {
        myDeviceDao.deleteAllDevices()
    }

    suspend fun update(myDeviceEntity: MyDeviceEntity) {
        myDeviceDao.update(myDeviceEntity)
    }
}


package com.medbiz.sdk.openapi.entity

import java.io.Serializable

data class OAuthClientInformation(
        var clientID: String,
        var clientSecret: String?,
        var redirectURI: String?,
        var scope: String,
        var responseType: String,
        var grantType: String?
): Serializable
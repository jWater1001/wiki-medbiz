package com.medbiz.sdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AlertDialog
import com.medbiz.sdk.openapi.entity.OAuthToken
import java.io.Serializable
import java.util.regex.Pattern

class ImplicitWebViewClient(context: Context, serverInfo: OAuthImplicitInformation): WebViewClient() {
    val tag = ImplicitWebViewClient::class.java.name
    private val context = context
    private var redirectCode = false

    var oauthClient = serverInfo

    override fun shouldOverrideUrlLoading(webView: WebView, url: String): Boolean {
        if (url.contains(oauthClient.redirectURI +"#")) {
            webView.visibility = View.INVISIBLE
            val intent = Intent()
            val regex = ".*access_token=([a-zA-Z0-9].*).*&token_type=(.*)&expires_in=(.*)"
            val pattern = Pattern.compile(regex, Pattern.MULTILINE)
            val matcher = pattern.matcher(url)
            if (matcher.find()) {
                var mOAuthToken = OAuthToken(
                        matcher.group(1) as String,
                        matcher.group(2) as String ,
                        null,
                        matcher.group(3)!!.toInt(),
                        null)
                intent.putExtra("OAuthToken", mOAuthToken)

                (context as Activity).setResult(Activity.RESULT_OK, intent)
                context.finish()
            }
        }
        return false
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        super.onReceivedSslError(view, handler, error)

        val  builder = AlertDialog.Builder(context)
        builder.setMessage("이 사이트의 보안 인증서는 신뢰할 수 없습니다.");
        builder.setPositiveButton("계속") { _, _ ->
            handler?.proceed()
        }

        builder.setNegativeButton("취소") { _, _ ->
            handler?.cancel()
        }

        val dialog = builder.create()
        dialog.show()
    }
}

class OAuthImplicitInformation(
        clientID: String = "95b10b20791e6c493aaf21a474c6c45c",
        redirectURI: String = "https://localhost/auth",
        scope: String = "profile device"
): Serializable {
    var scheme = "https"
    var host = "auth.medbiz.or.kr"
    var responseType = "token"
    var redirectURI = redirectURI
    var targetURI = Uri.Builder()
            .scheme(scheme)
            .authority(host)
            .appendEncodedPath("oauth")
            .appendEncodedPath("authorize")
            .appendQueryParameter("response_type", responseType)
            .appendQueryParameter("client_id", clientID)
            .appendQueryParameter("redirect_uri", redirectURI)
            .appendQueryParameter("scope", scope)
            .build().toString()
}



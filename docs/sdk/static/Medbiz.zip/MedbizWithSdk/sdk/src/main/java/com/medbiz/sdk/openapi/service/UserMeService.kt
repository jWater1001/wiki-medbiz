package com.medbiz.sdk.openapi.service

import com.medbiz.sdk.openapi.entity.UserMe
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers

interface UserMeService {
    @Headers("Accept: application/json", "Content-Type: application/json")
    @GET("/user/me")
    fun getUserMe(
            @Header("Authorization") accessToken: String
    ): Call<UserMe>

    companion object {
        const val URL = "https://auth.medbiz.or.kr"
        fun invoke(): UserMeService = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(UserMeService::class.java)
    }


}
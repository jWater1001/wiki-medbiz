package com.medbiz.sdk.openapi

import android.media.Image
import android.util.Log
import com.medbiz.sdk.openapi.entity.MyDevice
import com.medbiz.sdk.openapi.entity.UserMe
import com.medbiz.sdk.openapi.service.PasswordAuthenticationService
import com.medbiz.sdk.openapi.service.UserMeService
import com.medbiz.sdk.room.entity.MyDeviceEntity
import com.medbiz.sdk.room.entity.UserMeEntity
import com.medbiz.sdk.room.repository.UserMeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserMe(repository: UserMeRepository) {
    private val tag = UserMe::class.java.name
    private val jobOpenApi = SupervisorJob()
    private val jobDB = SupervisorJob()
    private val openApiScope = CoroutineScope(Dispatchers.Main + jobOpenApi)
    private val dBScope = CoroutineScope(Dispatchers.Main + jobDB)

    private val repository = repository

    suspend fun getUserMe(accessToken: String) {
        openApiScope.launch {
            UserMeService.invoke().getUserMe(accessToken).enqueue(object: Callback<UserMe> {
                override fun onResponse(call: Call<UserMe>, response: Response<UserMe>) {
                    Log.d(tag, "${response.code()} ${response.body()}")
                    if (response.isSuccessful)
                    {
                        val body = response.body()!!
                        dBScope.launch {
                            repository.insert(
                                UserMeEntity(
                                        userName = body.userName,
                                        userMuid = body.userMuid,
                                        userId = body.userId,
                                        email = body.email,
                                        createAt = body.createAt,
                                        birthDay = body.birthDay,
                                        gender = body.gender,
                                        authorities = body.authorities.toString(),
                                        height = null,
                                        weight = null,
                                        totalWalk = null,
                                        activityLevel = null
                                )
                            )
                        }
                    }
                }

                override fun onFailure(call: Call<UserMe>, t: Throwable) {

                }
            })
        }
    }
}
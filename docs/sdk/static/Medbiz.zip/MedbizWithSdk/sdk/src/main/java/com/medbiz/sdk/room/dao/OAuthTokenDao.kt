package com.medbiz.sdk.room.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.medbiz.sdk.room.entity.OAuthTokenEntity

@Dao
interface OAuthTokenDao {
    @Query("SELECT COUNT(id) FROM oauth_token")
    suspend fun getSize(): Int

    @Query("SELECT * FROM oauth_token WHERE id=:id")
    fun getOAuthTokenFromDB(id: Int): LiveData<OAuthTokenEntity>

    @Query("SELECT * FROM oauth_token WHERE id=:id")
    suspend fun getOAuthToken(id: Int): OAuthTokenEntity

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vararg token: OAuthTokenEntity)

    @Delete
    suspend fun delete(vararg token: OAuthTokenEntity)

    @Update
    suspend fun update(token: OAuthTokenEntity)
}
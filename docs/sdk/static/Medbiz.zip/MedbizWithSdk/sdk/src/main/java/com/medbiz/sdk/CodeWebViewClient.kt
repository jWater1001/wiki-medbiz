package com.medbiz.sdk

import android.app.Activity
import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.util.Base64
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import com.medbiz.sdk.openapi.entity.OAuthToken
import com.medbiz.sdk.openapi.service.CodeAuthenticationTokenService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.Serializable
import java.util.regex.Pattern

class CodeWebViewClient(context: Context, serverInfo: OAuthCodeInformation): WebViewClient() {
    val tag = CodeWebViewClient::class.java.name
    private val context = context
    private var redirectCode = false
    var code: String = ""
    var oauthClient= serverInfo

    override fun shouldOverrideUrlLoading(webView: WebView, url: String): Boolean {
        if (url.contains(oauthClient.redirectURI+"?")) {
            val regex = ".*code=([a-zA-Z0-9].*)"
            val pattern = Pattern.compile(regex, Pattern.MULTILINE)
            val matcher = pattern.matcher(url)
            if (matcher.find()) {
                code = matcher.group(1) as String
                redirectCode = true
            }

            if(redirectCode) {
                webView.visibility = View.INVISIBLE
                val intent = Intent()

                CodeAuthenticationTokenService.invoke().getAccessToken(oauthClient.basicAuth, oauthClient.grantType, code, oauthClient.redirectURI).enqueue(object : Callback<OAuthToken> {
                    override fun onResponse(call: Call<OAuthToken>, response: Response<OAuthToken>) {
                        if (response.isSuccessful) {
                            intent.putExtra("OAuthToken", response.body())
                            (context as Activity).setResult(RESULT_OK, intent)
                            context.finish()
                        } else {
                        }
                    }
                    override fun onFailure(call: Call<OAuthToken>, t: Throwable) {
                    }
                })
            }
        }
        return false
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        super.onReceivedSslError(view, handler, error)

        val  builder = AlertDialog.Builder(context)
        builder.setMessage("이 사이트의 보안 인증서는 신뢰할 수 없습니다.");
        builder.setPositiveButton("계속") { _, _ ->
            handler?.proceed()
        }

        builder.setNegativeButton("취소") { _, _ ->
            handler?.cancel()
        }

        val dialog = builder.create()
        dialog.show()
    }

}

class OAuthCodeInformation(
        clientID: String = "95b10b20791e6c493aaf21a474c6c45c",
        clientSecret: String= "815da508fa084170a8df8f64173577c8",
        redirectURI: String = "https://localhost/auth",
        scope: String = "profile device"
) : Serializable {
    var scheme = "https"
    var host = "auth.medbiz.or.kr"
    var responseType = "code"
    var grantType = "authorization_code"
    var credential = "$clientID:$clientSecret"
    var basicAuth = "Basic " + Base64.encodeToString(credential.toByteArray(), Base64.NO_WRAP)
    var redirectURI = redirectURI
    var targetURI = Uri.Builder()
            .scheme(scheme)
            .authority(host)
            .appendEncodedPath("oauth")
            .appendEncodedPath("authorize")
            .appendQueryParameter("response_type", responseType)
            .appendQueryParameter("client_id", clientID)
            .appendQueryParameter("redirect_uri", redirectURI)
            .appendQueryParameter("scope", scope)
            .build().toString()
}



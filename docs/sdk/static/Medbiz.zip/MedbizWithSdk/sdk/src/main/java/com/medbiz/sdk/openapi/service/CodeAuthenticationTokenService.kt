package com.medbiz.sdk.openapi.service
import com.medbiz.sdk.openapi.entity.OAuthToken
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface CodeAuthenticationTokenService {
    @Headers("Accept: application/json", "Content-Type: application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("oauth/token")
    fun getAccessToken(
            @Header("Authorization") basicAuth: String,
            @Field("grant_type") grant_type: String,
            @Field("code") code: String,
            @Field("redirect_uri") redirect_uri: String
    ): Call<OAuthToken>

    @Headers("Accept: application/json", "Content-Type: application/x-www-form-urlencoded")
    @FormUrlEncoded
    @POST("oauth/token")
    fun getAccessTokenWithRefreshToken(
            @Header("Authorization") basicAuth: String,
            @Field("grant_type") grantType: String,
            @Field("scope") scope: String,
            @Field("refresh_token") refreshToken: String
    ): Call<OAuthToken>

    companion object {
        const val URL = "https://auth.medbiz.or.kr/"
        fun invoke(): CodeAuthenticationTokenService = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(CodeAuthenticationTokenService::class.java)
    }
}


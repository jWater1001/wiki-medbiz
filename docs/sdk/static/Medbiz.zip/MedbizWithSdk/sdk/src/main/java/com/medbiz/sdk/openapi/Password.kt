package com.medbiz.sdk.openapi

import android.util.Log
import com.medbiz.sdk.openapi.entity.OAuthClient
import com.medbiz.sdk.openapi.entity.OAuthClientInformation
import com.medbiz.sdk.openapi.entity.OAuthToken
import com.medbiz.sdk.openapi.service.PasswordAuthenticationService
import com.medbiz.sdk.room.entity.OAuthTokenEntity
import com.medbiz.sdk.room.repository.OAuthTokenRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch


class Password(repository: OAuthTokenRepository) {
    val tag = Password::class.java.name
    private val supervisorJob1 = SupervisorJob()
    private val supervisorJob2 = SupervisorJob()
    private val coroutineScope1 = CoroutineScope(Dispatchers.Main + supervisorJob1)
    private val coroutineScope2 = CoroutineScope(Dispatchers.Main + supervisorJob2)
    private val repository = repository

    private val client = OAuthClient(OAuthClientInformation(
            clientID = "95b10b20791e6c493aaf21a474c6c45c",
            clientSecret = "815da508fa084170a8df8f64173577c8",
            redirectURI = "https://localhost/auth",
            scope = "profile device",
            responseType = "token",
            grantType = "password"))

    private val clientInfo = client.clientInfo


    suspend fun requestAccessToken(username: String, password: String): OAuthToken? {
        var accessToken: OAuthToken? = null

        val res = PasswordAuthenticationService.invoke().getAccessToken(
                client.getBasicAuth(),
                clientInfo.grantType!!,
                username, password
        )

        when (res.code()) {
            in 200..299 -> {
                val body = res.body()!!
                accessToken = body.copy()
                coroutineScope2.launch {

                    val oAuthToken = OAuthTokenEntity(
                            body.accessToken,
                            body.tokenType,
                            body.refreshToken,
                            body.expiresIn,
                            body.scope,
                            res.code()
                    )
                    repository.insert(oAuthToken)
                }
            }
            in 400..499 -> {

            }
        }
        return accessToken
    }
}
package com.medbiz.sdk.room.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.medbiz.sdk.room.dao.OAuthTokenDao
import com.medbiz.sdk.room.database.MedbizSdkDB
import com.medbiz.sdk.room.entity.OAuthTokenEntity

class OAuthTokenRepository(application: Application) {
    private var oAuthTokenDao: OAuthTokenDao = MedbizSdkDB.getInstance(application)!!.oAuthTokenDao()

    fun getDBInstance(): MedbizSdkDB.Companion {
        return MedbizSdkDB
    }

//    var clientInfo = OAuthClientInformation(
//            clientID = "95b10b20791e6c493aaf21a474c6c45c",
//            clientSecret ="815da508fa084170a8df8f64173577c8",
//            redirectURI = "https://localhost/auth",
//            scope = "profile device",
//            responseType = "token",
//            grantType = "password")
//
//    var client = OAuthClient(clientInfo)

    suspend fun getSize(): Int {
        return oAuthTokenDao.getSize()
    }

    fun getOAuthTokenFromDB(id: Int=0): LiveData<OAuthTokenEntity> {
        return oAuthTokenDao.getOAuthTokenFromDB(id)
    }

    suspend fun getOAuthToken(id: Int=0): OAuthTokenEntity? {
        return oAuthTokenDao.getOAuthToken(id)
    }

    suspend fun insert(oAuthTokenEntity: OAuthTokenEntity) {
        oAuthTokenDao.insert(oAuthTokenEntity)
    }

    suspend fun delete(oAuthTokenEntity: OAuthTokenEntity) {
        oAuthTokenDao.delete(oAuthTokenEntity)
    }

    suspend fun update(oAuthTokenEntity: OAuthTokenEntity) {
        oAuthTokenDao.update(oAuthTokenEntity)
    }
}


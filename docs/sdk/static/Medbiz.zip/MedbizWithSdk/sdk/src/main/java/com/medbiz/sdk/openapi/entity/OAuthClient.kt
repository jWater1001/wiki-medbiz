package com.medbiz.sdk.openapi.entity

import android.util.Base64
import java.io.Serializable

data class OAuthClient (
        var clientInfo: OAuthClientInformation
): Serializable {
    var scheme = "https"
    var host = "auth.medbiz.or.kr"

    fun getCredential(): String {
        return "${clientInfo.clientID}:${clientInfo.clientSecret}"
    }

    fun getBasicAuth(): String {
        return "Basic " + Base64.encodeToString(this.getCredential().toByteArray(), Base64.NO_WRAP)
    }

//    fun build(): String {
//        var baseUri = Uri.Builder()
//                .scheme(scheme)
//                .authority(host)
//                .appendEncodedPath("oauth")
//                .appendEncodedPath("authorize")
//                .appendQueryParameter("response_type", clientInfo.responseType)
//                .appendQueryParameter("client_id", clientInfo.clientID)
//                .appendQueryParameter("redirect_uri", clientInfo.redirectURI)
//                .appendQueryParameter("scope", clientInfo.scope)
//
//        when (clientInfo.grantType) {
//            "authorization_code" -> {
//                baseUri = baseUri
//                        .appendQueryParameter("grant_type", clientInfo.grantType)
//            }
//            "implicit" -> {
//                baseUri = baseUri
//                        .appendQueryParameter("grant_type", clientInfo.grantType)
//            }
//            "password" -> {
//                baseUri = baseUri
//                        .appendQueryParameter("grant_type", clientInfo.grantType)
//                        .appendQueryParameter("username", clientInfo.username)
//                        .appendQueryParameter("password", clientInfo.password)
//            }
//        }
//        return baseUri.build().toString()
//    }
}
package com.medbiz.sdk.openapi.service

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface LogoutService {
    @GET("logout")
    fun logout(): Call<Void>

    companion object {
        const val URL = "https://auth.medbiz.or.kr/"
        fun invoke(): LogoutService = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(LogoutService::class.java)
    }
}
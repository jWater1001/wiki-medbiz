package com.medbiz.sdk.openapi.service

import com.medbiz.sdk.openapi.entity.Vfs

import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*


interface VfsService {
    @POST("/v1/catalog/cd")
    fun cd(
            @Header("Authorization") accessToken: String,
            @Header("Medbiz-Catalog-Id") catalogId: String,
            @Header("Medbiz-Catalog-Path") catalogPath: String
    ): Call<Vfs>

    @POST("/v1/catalog/ls")
    fun ls(
            @Header("Authorization") accessToken: String,
            @Header("Medbiz-Catalog-Id") catalogId: String,
            @Header("Medbiz-Catalog-Path") path: String,
            @Header("Medbiz-Catalog-Permission") linuxPermission: String
    ): Call<Vfs>

    @Multipart
    @POST("/v1/catalog/put")
    fun put(
            @Header("Authorization") accessToken: String,
            @Header("Medbiz-Catalog-Id") catalogId: String,
            @Header("Medbiz-Catalog-Path") path: String,
            @Header("Medbiz-Catalog-Contents-Length") contentLength: String,
            @Header("Medbiz-Catalog-Encryption") isEncryption: String,
            @Part file: MultipartBody.Part
    ): Call<Vfs>

    @POST("/v1/catalog/mkdir")
    fun mkdir(
            @Header("Authorization") accessToken: String,
            @Header("Medbiz-Catalog-Id") catalogId: String,
            @Header("Medbiz-Catalog-Path") path: String,
            @Header("Medbiz-Catalog-Permission") linuxPermission: String
    ): Call<Vfs>

    companion object {
        const val URL = "https://openapi.medbiz.or.kr"
        val retrofit = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(VfsService::class.java)

    }
}
package com.medbiz.sdk.openapi.entity

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Vfs(
        @SerializedName("status")
        private val status: Long,

        @SerializedName("method")
        private val method: String,

        @SerializedName("path")
        private val path: String,

        @SerializedName("errCode")
        private val errCode: Boolean,

        @SerializedName("message")
        private val message: String,

        @SerializedName("timestamp")
        private val timestamp: Long
): Serializable
package com.medbiz.sdk.openapi.entity

import java.io.Serializable

data class UserMe(
        val userMuid: String,
        val userId: String,
        val email: String,
        val createAt: String,
        val userName: String,
        val birthDay: String,
        val gender: String,
        val authorities: List<String>
): Serializable
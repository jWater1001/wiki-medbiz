package com.medbiz.sdk.openapi.service

import com.medbiz.sdk.openapi.entity.Item
import com.medbiz.sdk.openapi.entity.MyDevice
import com.medbiz.sdk.openapi.entity.MyDeviceEnrollment
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface MyDeviceService {
    @Headers("Accept: application/json", "Content-Type: application/json")
    @GET("/v1/devices")
    fun getMyDevices(
            @Header("Authorization") accessToken: String,
            @Query("page") page: Int,
            @Query("size") size: Int
    ): Call<MyDevice>

    @Headers("Content-Type: application/json")
    @POST("/v1/devices")
    fun addMyDevice(
            @Header("Authorization") accessToken: String,
            @Body myDeviceEnrollment: MyDeviceEnrollment
    ): Call<Item>

    @Headers("Content-Type: application/json")
    @DELETE("/v1/devices/{deviceMuid}")
    fun deleteMyDevice(
            @Header("Authorization") accessToken: String,
            @Path("deviceMuid") deviceMuid: String

    ): Call<Item>

    companion object {
        const val URL = "https://openapi.medbiz.or.kr"
        fun invoke(): MyDeviceService = Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build().create(MyDeviceService::class.java)
    }
}